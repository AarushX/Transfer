// ============================================================
// D4 VARIATIONS — Field Manual Explorations (10 iterations)
// Starting from the core shop-floor aesthetic, exploring:
// - Status treatment (from experimental stamps → refined inline)
// - Color palettes (warm industrial, cool technical, neutral bureaucratic)
// - Typography pairings (condensed + readable)
// - Layout density (spacious vs. compact)
// ============================================================

import React, { useState } from 'react';

// Base color palette
const d4 = {
  paper: '#FAF8F2',
  card: '#FFFFFF',
  ink: '#16190F',
  muted: '#55604F',
  dim: '#8C947F',
  rule: '#16190F',
  ruleSoft: '#D9D9CC',
  green: '#1C8F43',
  greenDeep: '#0E6B22',
  orange: '#C95F00',
  cond: "'Saira Condensed', sans-serif",
  body: "'Atkinson Hyperlegible', sans-serif",
  mono: "'JetBrains Mono', monospace",
};

// ============================================================
// V1: BASELINE (current field manual with refined stamps)
// ============================================================
function V1Dashboard() {
  return (
    <div style={v1Styles.shell}>
      <header style={v1Styles.header}>
        <div style={v1Styles.headerInner}>
          <span style={v1Styles.title}>CircuitRunners · Training Record</span>
          <span style={{ flex: 1 }}></span>
          <span style={v1Styles.meta}>DOC CR-DB-01 · REV 2026.06 · SHARMA, A. · CR-0427</span>
        </div>
        <div style={v1Styles.hazard}></div>
      </header>
      <div style={v1Styles.content}>
        <div style={v1Styles.titleSection}>
          <div style={v1Styles.pageTitle}>Daily worksheet</div>
          <div style={v1Styles.pageSubtitle}>WED 10 JUN 2026 · SHOP OPEN · SESSION 02:14</div>
        </div>
        <div style={v1Styles.statusRow}>
          <StatusBadgeV1 text="Checked in" color={d4.green} />
          <StatusBadgeV1 text="3 checkoffs awaiting" color={d4.orange} />
        </div>
      </div>
    </div>
  );
}

const v1Styles = {
  shell: {
    background: d4.paper,
    color: d4.ink,
    fontFamily: d4.body,
    display: 'flex',
    flexDirection: 'column',
    minHeight: 400,
  },
  header: {
    background: d4.ink,
    color: '#F4F2E8',
    flexShrink: 0,
  },
  headerInner: {
    display: 'flex',
    alignItems: 'center',
    gap: 14,
    padding: '12px 26px',
  },
  title: {
    fontFamily: d4.cond,
    fontWeight: 700,
    fontSize: 22,
    letterSpacing: '0.22em',
    textTransform: 'uppercase',
  },
  meta: {
    fontFamily: d4.mono,
    fontSize: 10,
    color: '#B9C2A9',
  },
  hazard: {
    height: 8,
    background: 'repeating-linear-gradient(-45deg, #F4F2E8 0 12px, #1C8F43 12px 24px)',
  },
  content: {
    flex: 1,
    padding: '24px 30px',
  },
  titleSection: {
    marginBottom: 20,
  },
  pageTitle: {
    fontFamily: d4.cond,
    fontWeight: 700,
    fontSize: 34,
    letterSpacing: '0.04em',
    textTransform: 'uppercase',
    lineHeight: 1,
  },
  pageSubtitle: {
    fontFamily: d4.mono,
    fontSize: 11.5,
    color: d4.muted,
    marginTop: 4,
  },
  statusRow: {
    display: 'flex',
    alignItems: 'center',
    gap: 18,
  },
};

function StatusBadgeV1({ text, color }) {
  return (
    <span
      style={{
        display: 'inline-block',
        transform: 'rotate(-2deg)',
        border: `2.5px solid ${color}`,
        color,
        fontFamily: d4.cond,
        fontWeight: 700,
        fontSize: 13,
        letterSpacing: '0.14em',
        textTransform: 'uppercase',
        padding: '4px 12px',
        borderRadius: 3,
        opacity: 0.9,
      }}
    >
      {text}
    </span>
  );
}

// ============================================================
// V2: REFINED INLINE STATUS (no stamp styling)
// ============================================================
function V2Dashboard() {
  return (
    <div style={v2Styles.shell}>
      <header style={v2Styles.header}>
        <div style={v2Styles.headerInner}>
          <span style={v2Styles.title}>CircuitRunners · Training Record</span>
          <span style={{ flex: 1 }}></span>
          <span style={v2Styles.meta}>DOC CR-DB-01 · REV 2026.06 · SHARMA, A. · CR-0427</span>
        </div>
        <div style={v2Styles.hazard}></div>
      </header>
      <div style={v2Styles.content}>
        <div style={v2Styles.titleSection}>
          <div style={v2Styles.pageTitle}>Daily worksheet</div>
          <div style={v2Styles.pageSubtitle}>WED 10 JUN 2026 · SHOP OPEN · SESSION 02:14</div>
        </div>
        <div style={v2Styles.statusRow}>
          <StatusBadgeV2 text="Checked in" color={d4.green} />
          <StatusBadgeV2 text="3 checkoffs awaiting" color={d4.orange} />
        </div>
      </div>
    </div>
  );
}

const v2Styles = {
  ...v1Styles,
};

function StatusBadgeV2({ text, color }) {
  return (
    <span
      style={{
        display: 'inline-block',
        fontFamily: d4.mono,
        fontWeight: 600,
        fontSize: 11,
        letterSpacing: '0.08em',
        textTransform: 'uppercase',
        padding: '6px 10px',
        borderRadius: 0,
        background: color,
        color: '#fff',
      }}
    >
      {text}
    </span>
  );
}

// ============================================================
// V3: PILL BADGES WITH DOT INDICATOR
// ============================================================
function V3Dashboard() {
  return (
    <div style={v3Styles.shell}>
      <header style={v3Styles.header}>
        <div style={v3Styles.headerInner}>
          <span style={v3Styles.title}>CircuitRunners · Training Record</span>
          <span style={{ flex: 1 }}></span>
          <span style={v3Styles.meta}>DOC CR-DB-01 · REV 2026.06 · SHARMA, A. · CR-0427</span>
        </div>
        <div style={v3Styles.hazard}></div>
      </header>
      <div style={v3Styles.content}>
        <div style={v3Styles.titleSection}>
          <div style={v3Styles.pageTitle}>Daily worksheet</div>
          <div style={v3Styles.pageSubtitle}>WED 10 JUN 2026 · SHOP OPEN · SESSION 02:14</div>
        </div>
        <div style={v3Styles.statusRow}>
          <StatusBadgeV3 text="Checked in" color={d4.green} />
          <StatusBadgeV3 text="3 checkoffs awaiting" color={d4.orange} />
        </div>
      </div>
    </div>
  );
}

const v3Styles = {
  ...v1Styles,
};

function StatusBadgeV3({ text, color }) {
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        fontFamily: d4.mono,
        fontWeight: 600,
        fontSize: 11,
        letterSpacing: '0.08em',
        textTransform: 'uppercase',
        padding: '7px 14px',
        borderRadius: 20,
        background: color,
        color: '#fff',
      }}
    >
      <span style={{ width: 6, height: 6, borderRadius: 3, background: 'rgba(255,255,255,0.6)' }}></span>
      {text}
    </span>
  );
}

// ============================================================
// V4: BORDERED TAGS (no fill)
// ============================================================
function V4Dashboard() {
  return (
    <div style={v4Styles.shell}>
      <header style={v4Styles.header}>
        <div style={v4Styles.headerInner}>
          <span style={v4Styles.title}>CircuitRunners · Training Record</span>
          <span style={{ flex: 1 }}></span>
          <span style={v4Styles.meta}>DOC CR-DB-01 · REV 2026.06 · SHARMA, A. · CR-0427</span>
        </div>
        <div style={v4Styles.hazard}></div>
      </header>
      <div style={v4Styles.content}>
        <div style={v4Styles.titleSection}>
          <div style={v4Styles.pageTitle}>Daily worksheet</div>
          <div style={v4Styles.pageSubtitle}>WED 10 JUN 2026 · SHOP OPEN · SESSION 02:14</div>
        </div>
        <div style={v4Styles.statusRow}>
          <StatusBadgeV4 text="Checked in" color={d4.green} />
          <StatusBadgeV4 text="3 checkoffs awaiting" color={d4.orange} />
        </div>
      </div>
    </div>
  );
}

const v4Styles = {
  ...v1Styles,
};

function StatusBadgeV4({ text, color }) {
  return (
    <span
      style={{
        display: 'inline-block',
        fontFamily: d4.mono,
        fontWeight: 700,
        fontSize: 11,
        letterSpacing: '0.08em',
        textTransform: 'uppercase',
        padding: '7px 14px',
        borderRadius: 3,
        border: `1.5px solid ${color}`,
        color: color,
        background: '#fff',
      }}
    >
      {text}
    </span>
  );
}

// ============================================================
// V5: MONOSPACE CAPSULE
// ============================================================
function V5Dashboard() {
  return (
    <div style={v5Styles.shell}>
      <header style={v5Styles.header}>
        <div style={v5Styles.headerInner}>
          <span style={v5Styles.title}>CircuitRunners · Training Record</span>
          <span style={{ flex: 1 }}></span>
          <span style={v5Styles.meta}>DOC CR-DB-01 · REV 2026.06 · SHARMA, A. · CR-0427</span>
        </div>
        <div style={v5Styles.hazard}></div>
      </header>
      <div style={v5Styles.content}>
        <div style={v5Styles.titleSection}>
          <div style={v5Styles.pageTitle}>Daily worksheet</div>
          <div style={v5Styles.pageSubtitle}>WED 10 JUN 2026 · SHOP OPEN · SESSION 02:14</div>
        </div>
        <div style={v5Styles.statusRow}>
          <StatusBadgeV5 text="CHECKED IN" color={d4.green} />
          <StatusBadgeV5 text="3 AWAITING" color={d4.orange} />
        </div>
      </div>
    </div>
  );
}

const v5Styles = {
  ...v1Styles,
};

function StatusBadgeV5({ text, color }) {
  return (
    <span
      style={{
        display: 'inline-block',
        fontFamily: d4.mono,
        fontWeight: 700,
        fontSize: 9.5,
        letterSpacing: '0.12em',
        textTransform: 'uppercase',
        padding: '8px 12px',
        borderRadius: 20,
        background: color,
        color: '#fff',
        border: `2px solid ${color}`,
      }}
    >
      {text}
    </span>
  );
}

// ============================================================
// V6: INLINE WITH ICON DOT
// ============================================================
function V6Dashboard() {
  return (
    <div style={v6Styles.shell}>
      <header style={v6Styles.header}>
        <div style={v6Styles.headerInner}>
          <span style={v6Styles.title}>CircuitRunners · Training Record</span>
          <span style={{ flex: 1 }}></span>
          <span style={v6Styles.meta}>DOC CR-DB-01 · REV 2026.06 · SHARMA, A. · CR-0427</span>
        </div>
        <div style={v6Styles.hazard}></div>
      </header>
      <div style={v6Styles.content}>
        <div style={v6Styles.titleSection}>
          <div style={v6Styles.pageTitle}>Daily worksheet</div>
          <div style={v6Styles.pageSubtitle}>WED 10 JUN 2026 · SHOP OPEN · SESSION 02:14</div>
        </div>
        <div style={v6Styles.statusRow}>
          <StatusBadgeV6 text="Checked in" color={d4.green} />
          <StatusBadgeV6 text="3 checkoffs awaiting" color={d4.orange} />
        </div>
      </div>
    </div>
  );
}

const v6Styles = {
  ...v1Styles,
};

function StatusBadgeV6({ text, color }) {
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        fontFamily: d4.cond,
        fontWeight: 700,
        fontSize: 13,
        letterSpacing: '0.06em',
        textTransform: 'uppercase',
        color: color,
      }}
    >
      <span style={{ width: 8, height: 8, borderRadius: 4, background: color }}></span>
      {text}
    </span>
  );
}

// ============================================================
// V7: GHOST BUTTON (outline with hollow)
// ============================================================
function V7Dashboard() {
  return (
    <div style={v7Styles.shell}>
      <header style={v7Styles.header}>
        <div style={v7Styles.headerInner}>
          <span style={v7Styles.title}>CircuitRunners · Training Record</span>
          <span style={{ flex: 1 }}></span>
          <span style={v7Styles.meta}>DOC CR-DB-01 · REV 2026.06 · SHARMA, A. · CR-0427</span>
        </div>
        <div style={v7Styles.hazard}></div>
      </header>
      <div style={v7Styles.content}>
        <div style={v7Styles.titleSection}>
          <div style={v7Styles.pageTitle}>Daily worksheet</div>
          <div style={v7Styles.pageSubtitle}>WED 10 JUN 2026 · SHOP OPEN · SESSION 02:14</div>
        </div>
        <div style={v7Styles.statusRow}>
          <StatusBadgeV7 text="Checked in" color={d4.green} />
          <StatusBadgeV7 text="3 checkoffs awaiting" color={d4.orange} />
        </div>
      </div>
    </div>
  );
}

const v7Styles = {
  ...v1Styles,
};

function StatusBadgeV7({ text, color }) {
  return (
    <span
      style={{
        display: 'inline-block',
        fontFamily: d4.mono,
        fontWeight: 600,
        fontSize: 10,
        letterSpacing: '0.1em',
        textTransform: 'uppercase',
        padding: '8px 16px',
        borderRadius: 4,
        border: `2px solid ${color}`,
        color: color,
        background: 'transparent',
      }}
    >
      {text}
    </span>
  );
}

// ============================================================
// V8: INLINE TEXT WITH UNDERLINE
// ============================================================
function V8Dashboard() {
  return (
    <div style={v8Styles.shell}>
      <header style={v8Styles.header}>
        <div style={v8Styles.headerInner}>
          <span style={v8Styles.title}>CircuitRunners · Training Record</span>
          <span style={{ flex: 1 }}></span>
          <span style={v8Styles.meta}>DOC CR-DB-01 · REV 2026.06 · SHARMA, A. · CR-0427</span>
        </div>
        <div style={v8Styles.hazard}></div>
      </header>
      <div style={v8Styles.content}>
        <div style={v8Styles.titleSection}>
          <div style={v8Styles.pageTitle}>Daily worksheet</div>
          <div style={v8Styles.pageSubtitle}>WED 10 JUN 2026 · SHOP OPEN · SESSION 02:14</div>
        </div>
        <div style={v8Styles.statusRow}>
          <StatusBadgeV8 text="Checked in" color={d4.green} />
          <StatusBadgeV8 text="3 checkoffs awaiting" color={d4.orange} />
        </div>
      </div>
    </div>
  );
}

const v8Styles = {
  ...v1Styles,
};

function StatusBadgeV8({ text, color }) {
  return (
    <span
      style={{
        display: 'inline-block',
        fontFamily: d4.cond,
        fontWeight: 700,
        fontSize: 14,
        letterSpacing: '0.06em',
        textTransform: 'uppercase',
        color: color,
        borderBottom: `2.5px solid ${color}`,
        paddingBottom: 3,
      }}
    >
      {text}
    </span>
  );
}

// ============================================================
// V9: FILLED RECTANGLE WITH ICON
// ============================================================
function V9Dashboard() {
  return (
    <div style={v9Styles.shell}>
      <header style={v9Styles.header}>
        <div style={v9Styles.headerInner}>
          <span style={v9Styles.title}>CircuitRunners · Training Record</span>
          <span style={{ flex: 1 }}></span>
          <span style={v9Styles.meta}>DOC CR-DB-01 · REV 2026.06 · SHARMA, A. · CR-0427</span>
        </div>
        <div style={v9Styles.hazard}></div>
      </header>
      <div style={v9Styles.content}>
        <div style={v9Styles.titleSection}>
          <div style={v9Styles.pageTitle}>Daily worksheet</div>
          <div style={v9Styles.pageSubtitle}>WED 10 JUN 2026 · SHOP OPEN · SESSION 02:14</div>
        </div>
        <div style={v9Styles.statusRow}>
          <StatusBadgeV9 text="Checked in" color={d4.green} />
          <StatusBadgeV9 text="3 checkoffs awaiting" color={d4.orange} />
        </div>
      </div>
    </div>
  );
}

const v9Styles = {
  ...v1Styles,
};

function StatusBadgeV9({ text, color }) {
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        fontFamily: d4.mono,
        fontWeight: 600,
        fontSize: 10,
        letterSpacing: '0.08em',
        textTransform: 'uppercase',
        padding: '7px 12px',
        borderRadius: 2,
        background: color,
        color: '#fff',
      }}
    >
      <span style={{ fontSize: 12, fontWeight: 700 }}>●</span>
      {text}
    </span>
  );
}

// ============================================================
// V10: MINIMAL CAPS ONLY (no badge, just styled text)
// ============================================================
function V10Dashboard() {
  return (
    <div style={v10Styles.shell}>
      <header style={v10Styles.header}>
        <div style={v10Styles.headerInner}>
          <span style={v10Styles.title}>CircuitRunners · Training Record</span>
          <span style={{ flex: 1 }}></span>
          <span style={v10Styles.meta}>DOC CR-DB-01 · REV 2026.06 · SHARMA, A. · CR-0427</span>
        </div>
        <div style={v10Styles.hazard}></div>
      </header>
      <div style={v10Styles.content}>
        <div style={v10Styles.titleSection}>
          <div style={v10Styles.pageTitle}>Daily worksheet</div>
          <div style={v10Styles.pageSubtitle}>WED 10 JUN 2026 · SHOP OPEN · SESSION 02:14</div>
        </div>
        <div style={v10Styles.statusRow}>
          <StatusBadgeV10 text="Checked in" color={d4.green} />
          <StatusBadgeV10 text="3 checkoffs awaiting" color={d4.orange} />
        </div>
      </div>
    </div>
  );
}

const v10Styles = {
  ...v1Styles,
};

function StatusBadgeV10({ text, color }) {
  return (
    <span
      style={{
        display: 'inline-block',
        fontFamily: d4.mono,
        fontWeight: 700,
        fontSize: 11,
        letterSpacing: '0.1em',
        textTransform: 'uppercase',
        color: color,
      }}
    >
      {text}
    </span>
  );
}

// ============================================================
// Main explorer component
// ============================================================
export default function FieldManualVariations() {
  const [selected, setSelected] = useState('v1');

  const variants = [
    { id: 'v1', name: 'V1 — Baseline (refined stamps)', Component: V1Dashboard },
    { id: 'v2', name: 'V2 — Solid pill (no rotation)', Component: V2Dashboard },
    { id: 'v3', name: 'V3 — Pill with dot', Component: V3Dashboard },
    { id: 'v4', name: 'V4 — Bordered tags', Component: V4Dashboard },
    { id: 'v5', name: 'V5 — Monospace capsule', Component: V5Dashboard },
    { id: 'v6', name: 'V6 — Inline with dot', Component: V6Dashboard },
    { id: 'v7', name: 'V7 — Ghost button', Component: V7Dashboard },
    { id: 'v8', name: 'V8 — Underline text', Component: V8Dashboard },
    { id: 'v9', name: 'V9 — Filled rect + dot', Component: V9Dashboard },
    { id: 'v10', name: 'V10 — Minimal text only', Component: V10Dashboard },
  ];

  const CurrentComponent = variants.find((v) => v.id === selected).Component;

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: '#fafaf8' }}>
      {/* Sidebar */}
      <div
        style={{
          width: 280,
          background: '#f5f3ed',
          borderRight: '1px solid #d9d9cc',
          padding: '20px',
          overflowY: 'auto',
          flexShrink: 0,
        }}
      >
        <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 20, fontFamily: "'Saira Condensed', sans-serif", letterSpacing: '0.08em' }}>
          VARIATIONS
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {variants.map((v) => (
            <button
              key={v.id}
              onClick={() => setSelected(v.id)}
              style={{
                padding: '10px 12px',
                background: selected === v.id ? d4.ink : 'transparent',
                color: selected === v.id ? '#F4F2E8' : d4.ink,
                border: 'none',
                cursor: 'pointer',
                fontFamily: d4.mono,
                fontSize: 11,
                fontWeight: 600,
                letterSpacing: '0.08em',
                textAlign: 'left',
                borderRadius: 3,
                transition: 'all 0.2s',
              }}
            >
              {v.name}
            </button>
          ))}
        </div>
      </div>

      {/* Preview */}
      <div style={{ flex: 1, padding: '20px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ width: '100%', maxWidth: 900, background: '#fff', borderRadius: 4, boxShadow: '0 2px 12px rgba(0,0,0,0.08)' }}>
          <CurrentComponent />
        </div>
      </div>
    </div>
  );
}
