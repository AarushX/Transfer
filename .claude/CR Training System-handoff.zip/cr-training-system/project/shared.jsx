// ============================================================
// Shared data + helpers for CircuitRunners UI explorations
// ============================================================

// ---- Brand (modernized green family) ----
// Original brand: #23B24D primary, #0C660C secondary, #C36000 alloy orange,
// #303030 grey, #000 black, #FFF white.
// Modernized: same hue family, tuned per-surface via oklch-adjacent picks.
const CR = {
  green: '#27B855',       // modernized primary (slightly cooler, brighter)
  greenBright: '#3DDC74', // dark-mode accent
  greenDeep: '#0E6B22',   // modernized secondary
  orange: '#C95F00',      // alloy orange, nudged
  orangeBright: '#E8842A',// dark-mode orange
  ink: '#101411',         // green-tinted near-black
  paper: '#FAFAF7',       // warm paper white
};

// ---- Realistic course data (from the actual app's domain) ----
const COURSES = [
  { title: 'Mill Safety & Operation', team: 'Mechanical', status: 'in_progress', done: 2, total: 4 },
  { title: 'Intro to CAD: Onshape Basics', team: 'Mechanical', status: 'in_progress', done: 1, total: 3 },
  { title: 'Soldering Certification', team: 'Electrical', status: 'ready', done: 0, total: 3 },
  { title: 'Java Fundamentals', team: 'Programming', status: 'ready', done: 0, total: 5 },
  { title: 'Bandsaw Certification', team: 'Mechanical', status: 'ready', done: 0, total: 3 },
  { title: 'Electrical Wiring & CAN Bus', team: 'Electrical', status: 'ready', done: 0, total: 4 },
  { title: 'Pneumatics Basics', team: 'Mechanical', status: 'ready', done: 0, total: 3 },
  { title: '3D Printing Workflow', team: 'Mechanical', status: 'ready', done: 0, total: 2 },
  { title: 'Git & Version Control', team: 'Programming', status: 'ready', done: 0, total: 3 },
];

// Skill tree graph — nodes with x/y in a 0..100 space, prereq edges.
// status: completed | in_progress | available | pending | locked
const TREE_NODES = [
  { id: 'safety',   title: 'Shop Safety Basics',        x: 8,  y: 38, team: 'General',     status: 'completed' },
  { id: 'handtool', title: 'Hand Tools',                x: 24, y: 16, team: 'Mechanical',  status: 'completed' },
  { id: 'cad',      title: 'Onshape Basics',            x: 24, y: 52, team: 'Mechanical',  status: 'in_progress' },
  { id: 'mill',     title: 'Mill Safety & Operation',   x: 42, y: 10, team: 'Mechanical',  status: 'in_progress' },
  { id: 'bandsaw',  title: 'Bandsaw Certification',     x: 42, y: 30, team: 'Mechanical',  status: 'available' },
  { id: 'cadadv',   title: 'Advanced CAD: Assemblies',  x: 42, y: 52, team: 'Mechanical',  status: 'locked' },
  { id: 'print3d',  title: '3D Printing Workflow',      x: 42, y: 72, team: 'Mechanical',  status: 'available' },
  { id: 'solder',   title: 'Soldering Certification',   x: 24, y: 88, team: 'Electrical',  status: 'pending' },
  { id: 'wiring',   title: 'Wiring & CAN Bus',          x: 42, y: 90, team: 'Electrical',  status: 'locked' },
  { id: 'lathe',    title: 'Lathe Certification',       x: 60, y: 18, team: 'Mechanical',  status: 'locked' },
  { id: 'cnc',      title: 'CNC Router',                x: 60, y: 40, team: 'Mechanical',  status: 'locked' },
  { id: 'pneu',     title: 'Pneumatics Basics',         x: 60, y: 62, team: 'Mechanical',  status: 'available' },
  { id: 'drivetrain', title: 'Drivetrain Assembly',     x: 78, y: 30, team: 'Mechanical',  status: 'locked' },
  { id: 'electronics', title: 'Robot Electronics Board', x: 60, y: 84, team: 'Electrical', status: 'locked' },
  { id: 'inspect',  title: 'Robot Inspection',          x: 92, y: 52, team: 'General',     status: 'locked' },
];
const TREE_EDGES = [
  ['safety', 'handtool'], ['safety', 'cad'], ['safety', 'solder'],
  ['handtool', 'mill'], ['handtool', 'bandsaw'],
  ['cad', 'cadadv'], ['cad', 'print3d'],
  ['mill', 'lathe'], ['bandsaw', 'cnc'], ['cadadv', 'cnc'],
  ['cnc', 'drivetrain'], ['lathe', 'drivetrain'],
  ['cadadv', 'pneu'], ['solder', 'wiring'], ['wiring', 'electronics'],
  ['drivetrain', 'inspect'], ['pneu', 'inspect'], ['electronics', 'inspect'],
];

// Course player blocks for "Mill Safety & Operation"
const PLAYER_BLOCKS = [
  { type: 'video',    title: 'Vertical Mill Safety Video', meta: '12 min', state: 'done' },
  { type: 'reading',  title: 'Speeds, Feeds & Workholding', meta: '5 min read', state: 'done' },
  { type: 'quiz',     title: 'Mill Safety Quiz', meta: '7 questions · 80% to pass', state: 'current' },
  { type: 'checkoff', title: 'Mentor Checkoff: Facing Pass', meta: 'In-shop demo', state: 'upcoming' },
];

const QUIZ_QUESTION = {
  n: 3, of: 7,
  q: 'Before starting the mill, the workpiece must be…',
  options: [
    'Held by hand against the fence',
    'Clamped in the vise or fixtured to the table',
    'Taped down with double-sided tape',
    'Resting freely on parallels',
  ],
  picked: 1,
};

const CHECKLIST = [
  'Safety glasses on, sleeves secured, no jewelry',
  'Workpiece properly clamped in vise',
  'Correct spindle RPM set for material',
  'Performs facing pass with proper feed',
  'Cleans chips with brush — never hands',
];

// ---- Tiny shared atoms ----

// Fake QR placeholder — finder squares + noise grid. Never a real QR.
function FakeQR({ size = 96, dark = '#101411', light = '#ffffff' }) {
  const cells = [];
  // deterministic pseudo-noise
  let seed = 7;
  const rand = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
  const N = 13;
  for (let r = 0; r < N; r++) {
    for (let c = 0; c < N; c++) {
      const inFinder = (r < 4 && c < 4) || (r < 4 && c >= N - 4) || (r >= N - 4 && c < 4);
      if (!inFinder && rand() > 0.55) cells.push([r, c]);
    }
  }
  const u = size / N;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ display: 'block', background: light, borderRadius: 6 }}>
      {[[0, 0], [0, N - 4], [N - 4, 0]].map(([r, c], i) => (
        <g key={i}>
          <rect x={c * u + u * 0.3} y={r * u + u * 0.3} width={u * 3.4} height={u * 3.4} fill="none" stroke={dark} strokeWidth={u * 0.55} />
          <rect x={c * u + u * 1.3} y={r * u + u * 1.3} width={u * 1.4} height={u * 1.4} fill={dark} />
        </g>
      ))}
      {cells.map(([r, c], i) => (
        <rect key={'c' + i} x={c * u + u * 0.15} y={r * u + u * 0.15} width={u * 0.7} height={u * 0.7} fill={dark} />
      ))}
    </svg>
  );
}

// Simple line icons (stroke=currentColor)
const Icon = {
  play: (s = 16) => (<svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"><polygon points="6 4 20 12 6 20 6 4" /></svg>),
  book: (s = 16) => (<svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" /><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" /></svg>),
  quiz: (s = 16) => (<svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M9 11l3 3L22 4" /><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" /></svg>),
  wrench: (s = 16) => (<svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" /></svg>),
  home: (s = 16) => (<svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" /><polyline points="9 22 9 12 15 12 15 22" /></svg>),
  grid: (s = 16) => (<svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7" /><rect x="14" y="3" width="7" height="7" /><rect x="14" y="14" width="7" height="7" /><rect x="3" y="14" width="7" height="7" /></svg>),
  scan: (s = 16) => (<svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M3 7V5a2 2 0 0 1 2-2h2" /><path d="M17 3h2a2 2 0 0 1 2 2v2" /><path d="M21 17v2a2 2 0 0 1-2 2h-2" /><path d="M7 21H5a2 2 0 0 1-2-2v-2" /><line x1="7" y1="12" x2="17" y2="12" /></svg>),
  tree: (s = 16) => (<svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="5" cy="6" r="2.2" /><circle cx="19" cy="6" r="2.2" /><circle cx="12" cy="18" r="2.2" /><path d="M6.5 7.5L10.5 16M17.5 7.5L13.5 16" /></svg>),
  user: (s = 16) => (<svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" /></svg>),
  clock: (s = 16) => (<svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="9" /><polyline points="12 7 12 12 15 14" /></svg>),
  award: (s = 16) => (<svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="8" r="6" /><path d="M15.5 13L17 22l-5-3-5 3 1.5-9" /></svg>),
  check: (s = 16) => (<svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>),
  lock: (s = 16) => (<svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="4" y="11" width="16" height="10" rx="2" /><path d="M8 11V7a4 4 0 0 1 8 0v4" /></svg>),
  arrowR: (s = 16) => (<svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="4" y1="12" x2="20" y2="12" /><polyline points="13 5 20 12 13 19" /></svg>),
};

Object.assign(window, { CR, COURSES, TREE_NODES, TREE_EDGES, PLAYER_BLOCKS, QUIZ_QUESTION, CHECKLIST, FakeQR, Icon });
