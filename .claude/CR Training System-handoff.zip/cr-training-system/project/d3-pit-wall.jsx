// ============================================================
// D3 — PIT WALL (experimental · dark)
// Race-ops console. No sidebar: a dense top status bar, mono
// telemetry, numbered action queue, schematic skill map.
// ============================================================

const d3 = {
  bg: '#0A0C0B',
  panel: '#10140F',
  panel2: '#151A14',
  border: '#222B22',
  borderLit: '#35452F',
  text: '#DCE8DC',
  muted: '#8FA391',
  dim: '#5C6E5E',
  green: '#3DDC74',
  greenDeep: '#27B855',
  orange: '#E8842A',
  red: '#E85B4A',
  mono: "'JetBrains Mono', monospace",
  sans: "'Archivo', sans-serif",
};

const d3Code = { safety: 'GEN-001', handtool: 'MEC-010', cad: 'MEC-020', mill: 'MEC-101', bandsaw: 'MEC-102', cadadv: 'MEC-120', print3d: 'MEC-030', solder: 'ELE-010', wiring: 'ELE-101', lathe: 'MEC-103', cnc: 'MEC-201', pneu: 'MEC-110', drivetrain: 'MEC-301', electronics: 'ELE-201', inspect: 'GEN-900' };
const d3TeamPrefix = { Mechanical: 'MEC', Electrical: 'ELE', Programming: 'PRG', General: 'GEN' };

function D3Tag({ children, color = d3.muted, style }) {
  return <span style={{ fontFamily: d3.mono, fontSize: 9.5, fontWeight: 600, letterSpacing: '0.12em', textTransform: 'uppercase', color, ...style }}>{children}</span>;
}

function D3Panel({ title, right, children, style, pad = 14 }) {
  return (
    <section style={{ background: d3.panel, border: `1px solid ${d3.border}`, borderRadius: 4, display: 'flex', flexDirection: 'column', minWidth: 0, ...style }}>
      {title && (
        <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 12px', borderBottom: `1px solid ${d3.border}`, background: d3.panel2 }}>
          <D3Tag color={d3.muted}>{title}</D3Tag>
          {right}
        </header>
      )}
      <div style={{ padding: pad, flex: 1, minHeight: 0 }}>{children}</div>
    </section>
  );
}

function D3Shell({ children, active }) {
  const tabs = [['DASH', 'dash'], ['COURSES', 'player'], ['MAP', 'tree'], ['SCAN', null], ['MENTOR·3', null]];
  return (
    <div className="ab" style={{ background: d3.bg, color: d3.text, fontFamily: d3.sans, display: 'flex', flexDirection: 'column' }}>
      {/* subtle grid background */}
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', backgroundImage: 'linear-gradient(rgba(61,220,116,0.025) 1px, transparent 1px), linear-gradient(90deg, rgba(61,220,116,0.025) 1px, transparent 1px)', backgroundSize: '28px 28px' }}></div>
      {/* Status bar */}
      <header style={{ height: 46, flexShrink: 0, display: 'flex', alignItems: 'stretch', borderBottom: `1px solid ${d3.border}`, background: '#0D100C', position: 'relative' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9, padding: '0 16px', borderRight: `1px solid ${d3.border}` }}>
          <img src="brand/torm.png" alt="" style={{ width: 22, height: 21, objectFit: 'contain' }} />
          <span style={{ fontFamily: d3.mono, fontWeight: 700, fontSize: 12, letterSpacing: '0.14em' }}>CIRCUITRUNNERS</span>
        </div>
        <nav style={{ display: 'flex', alignItems: 'stretch' }}>
          {tabs.map(([t, key]) => (
            <span key={t} style={{ display: 'flex', alignItems: 'center', padding: '0 18px', fontFamily: d3.mono, fontSize: 11, fontWeight: 600, letterSpacing: '0.1em', color: key === active ? d3.green : d3.muted, borderBottom: key === active ? `2px solid ${d3.green}` : '2px solid transparent', background: key === active ? 'rgba(61,220,116,0.06)' : 'transparent' }}>{t}</span>
          ))}
        </nav>
        <div style={{ flex: 1 }}></div>
        {[
          ['SHOP', 'OPEN', d3.green],
          ['SESSION', '02:14:09', d3.text],
          ['HRS', '23.5/40', d3.text],
          ['QUEUE', '3 PEND', d3.orange],
        ].map(([l, v, c]) => (
          <div key={l} style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '0 16px', borderLeft: `1px solid ${d3.border}` }}>
            <D3Tag color={d3.dim}>{l}</D3Tag>
            <span style={{ fontFamily: d3.mono, fontSize: 12, fontWeight: 700, color: c }}>{v}</span>
          </div>
        ))}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '0 16px', borderLeft: `1px solid ${d3.border}` }}>
          <span style={{ width: 26, height: 26, borderRadius: 3, background: d3.greenDeep, color: '#06130A', display: 'grid', placeItems: 'center', fontFamily: d3.mono, fontWeight: 700, fontSize: 11 }}>AS</span>
          <span style={{ fontFamily: d3.mono, fontSize: 11, color: d3.muted }}>A.SHARMA</span>
        </div>
      </header>
      <main style={{ flex: 1, position: 'relative', padding: 14, minHeight: 0 }}>{children}</main>
    </div>
  );
}

function D3Meter({ pct, color = d3.green, h = 8, segments = 20 }) {
  const lit = Math.round((pct / 100) * segments);
  return (
    <div style={{ display: 'flex', gap: 2, height: h }}>
      {Array.from({ length: segments }, (_, i) => (
        <span key={i} style={{ flex: 1, background: i < lit ? color : '#1C231B', borderRadius: 1 }}></span>
      ))}
    </div>
  );
}

const d3Status = {
  in_progress: ['ACTIVE', d3.green],
  ready: ['READY', d3.muted],
  pending: ['HOLD·MENTOR', d3.orange],
  completed: ['CERT', d3.greenDeep],
  available: ['READY', d3.muted],
  locked: ['LOCKED', d3.dim],
};

// ---------------- Dashboard ----------------
function D3Dashboard() {
  return (
    <D3Shell active="dash">
      <div style={{ display: 'grid', gridTemplateColumns: '1.45fr 1fr 320px', gridTemplateRows: 'auto 1fr', gap: 12, height: '100%', position: 'relative' }}>
        {/* Action queue */}
        <D3Panel title="Action queue — do these next" right={<D3Tag color={d3.dim}>SORT: PRIORITY</D3Tag>} pad={0} style={{ gridRow: '1 / 3' }}>
          {COURSES.map((c, i) => {
            const [label, color] = d3Status[c.status];
            return (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px', borderBottom: `1px solid ${d3.border}`, background: i === 0 ? 'rgba(61,220,116,0.05)' : 'transparent' }}>
                <span style={{ fontFamily: d3.mono, fontSize: 11, color: d3.dim, width: 20 }}>{String(i + 1).padStart(2, '0')}</span>
                <span style={{ fontFamily: d3.mono, fontSize: 10, color: d3.muted, width: 62 }}>{d3TeamPrefix[c.team]}-{101 + i}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{c.title}</div>
                </div>
                {c.status === 'in_progress' && <div style={{ width: 90 }}><D3Meter pct={(c.done / c.total) * 100} h={5} segments={c.total} /></div>}
                <span style={{ fontFamily: d3.mono, fontSize: 9.5, fontWeight: 700, letterSpacing: '0.08em', color, border: `1px solid ${color}44`, padding: '2px 7px', borderRadius: 2, background: `${color}11` }}>{label}</span>
              </div>
            );
          })}
          <div style={{ padding: '10px 12px' }}><D3Tag color={d3.dim}>9 MODULES QUEUED · 12 CERTIFIED · EST 6.5 HRS TO CLEAR</D3Tag></div>
        </D3Panel>

        {/* Active module */}
        <D3Panel title="Active module" right={<D3Tag color={d3.green}>MEC-101</D3Tag>}>
          <div style={{ fontSize: 17, fontWeight: 700, fontFamily: d3.sans, marginBottom: 4 }}>Mill Safety & Operation</div>
          <D3Tag color={d3.dim}>MECHANICAL · 4 BLOCKS</D3Tag>
          <div style={{ margin: '14px 0 6px' }}><D3Meter pct={50} h={10} segments={4} /></div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <D3Tag color={d3.muted}>BLOCK 2/4 · QUIZ NEXT</D3Tag>
            <D3Tag color={d3.green}>50%</D3Tag>
          </div>
          <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 6 }}>
            {PLAYER_BLOCKS.map((b, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, fontFamily: d3.mono, fontSize: 11 }}>
                <span style={{ width: 12, textAlign: 'center', color: b.state === 'done' ? d3.green : b.state === 'current' ? d3.orange : d3.dim }}>{b.state === 'done' ? '■' : b.state === 'current' ? '▶' : '□'}</span>
                <span style={{ color: b.state === 'upcoming' ? d3.dim : d3.text, flex: 1 }}>{b.title.toUpperCase()}</span>
                <span style={{ color: d3.dim }}>{b.meta.split('·')[0]}</span>
              </div>
            ))}
          </div>
          <div style={{ marginTop: 16, display: 'inline-flex', alignItems: 'center', gap: 8, background: d3.green, color: '#06130A', fontFamily: d3.mono, fontWeight: 700, fontSize: 12, letterSpacing: '0.06em', padding: '9px 16px', borderRadius: 3 }}>RESUME ▸</div>
        </D3Panel>

        {/* ID + season telemetry */}
        <D3Panel title="Identity · passport" pad={12} style={{ gridRow: '1 / 3', display: 'flex' }}>
          <div style={{ display: 'flex', gap: 12 }}>
            <div style={{ background: '#fff', borderRadius: 4, padding: 6, alignSelf: 'flex-start' }}><FakeQR size={88} /></div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: d3.mono, fontSize: 12, fontWeight: 700 }}>SHARMA, AARUSH</div>
              <D3Tag color={d3.dim}>STUDENT · LEAD · CNC&MILL</D3Tag>
              <div style={{ marginTop: 8, fontFamily: d3.mono, fontSize: 10, color: d3.muted, lineHeight: 1.7 }}>
                ID&nbsp;&nbsp;CR-0427<br />VER&nbsp;v14<br />AUTH&nbsp;MILL · BANDSAW · 3DP
              </div>
            </div>
          </div>
          <div style={{ borderTop: `1px solid ${d3.border}`, margin: '12px -12px 0', padding: '12px 12px 0' }}>
            <D3Tag color={d3.muted}>Season hours</D3Tag>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, margin: '4px 0 6px' }}>
              <span style={{ fontFamily: d3.mono, fontSize: 26, fontWeight: 700 }}>23.5</span>
              <span style={{ fontFamily: d3.mono, fontSize: 11, color: d3.dim }}>/ 40 TARGET</span>
            </div>
            <D3Meter pct={59} />
            <div style={{ marginTop: 14 }}>
              <D3Tag color={d3.muted}>Lettering</D3Tag>
              <div style={{ marginTop: 6, display: 'flex', flexDirection: 'column', gap: 7 }}>
                {[['OUTREACH', 80, false], ['SHOP HRS', 59, false], ['COMP', 100, true], ['PARENT VOL', 20, false], ['MEDIA', 60, false]].map(([l, p, met]) => (
                  <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ fontFamily: d3.mono, fontSize: 9.5, color: d3.dim, width: 74 }}>{l}</span>
                    <div style={{ flex: 1 }}><D3Meter pct={p} h={5} segments={10} color={met ? d3.greenDeep : d3.green} /></div>
                    <span style={{ fontFamily: d3.mono, fontSize: 9.5, color: met ? d3.green : d3.muted, width: 30, textAlign: 'right' }}>{met ? 'MET' : p + '%'}</span>
                  </div>
                ))}
              </div>
            </div>
            <div style={{ marginTop: 14, borderTop: `1px solid ${d3.border}`, paddingTop: 10 }}>
              <D3Tag color={d3.muted}>Mentor queue · you</D3Tag>
              <div style={{ marginTop: 6, display: 'flex', flexDirection: 'column', gap: 5 }}>
                {[['R. CHEN', 'ELE-010 SOLDERING'], ['M. OKAFOR', 'MEC-102 BANDSAW'], ['J. PARK', 'MEC-101 MILL']].map(([n, m]) => (
                  <div key={n} style={{ display: 'flex', justifyContent: 'space-between', fontFamily: d3.mono, fontSize: 10 }}>
                    <span style={{ color: d3.text }}>{n}</span><span style={{ color: d3.orange }}>{m}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </D3Panel>

        {/* Tree preview */}
        <D3Panel title="Cert map — mechanical path" right={<D3Tag color={d3.dim}>FULL MAP ▸</D3Tag>} pad={0}>
          <D3TreeSvg height={300} compact />
        </D3Panel>
      </div>
    </D3Shell>
  );
}

// ---------------- Schematic tree ----------------
function d3NodeStyle(status) {
  switch (status) {
    case 'completed': return { fill: 'rgba(39,184,85,0.16)', stroke: d3.greenDeep, text: d3.text };
    case 'in_progress': return { fill: 'rgba(61,220,116,0.08)', stroke: d3.green, text: d3.text };
    case 'available': return { fill: 'transparent', stroke: '#4A5C4C', text: d3.text };
    case 'pending': return { fill: 'rgba(232,132,42,0.10)', stroke: d3.orange, text: d3.text };
    default: return { fill: 'transparent', stroke: '#27302A', text: d3.dim };
  }
}

function D3TreeSvg({ height = 620, compact = false, selected }) {
  const W = 1180, H = height, mx = 86, my = compact ? 24 : 46;
  const px = (x) => mx + (x / 100) * (W - mx * 2);
  const py = (y) => my + (y / 100) * (H - my * 2);
  const byId = Object.fromEntries(TREE_NODES.map((n) => [n.id, n]));
  const nw = compact ? 108 : 148, nh = compact ? 30 : 44;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', height, display: 'block' }}>
      {/* orthogonal PCB-style traces */}
      {TREE_EDGES.map(([a, b], i) => {
        const A = byId[a], B = byId[b];
        const x1 = px(A.x) + nw / 2, y1 = py(A.y), x2 = px(B.x) - nw / 2, y2 = py(B.y);
        const mid = x1 + (x2 - x1) * 0.5;
        const lit = A.status === 'completed';
        return (
          <g key={i}>
            <path d={`M ${x1} ${y1} H ${mid} V ${y2} H ${x2}`} fill="none" stroke={lit ? 'rgba(61,220,116,0.55)' : '#27302A'} strokeWidth={lit ? 1.6 : 1.1} />
            <circle cx={x2} cy={y2} r={2} fill={lit ? d3.green : '#3A463C'} />
          </g>
        );
      })}
      {TREE_NODES.map((n) => {
        const s = d3NodeStyle(n.status);
        const x = px(n.x), y = py(n.y);
        const isSel = selected === n.id;
        return (
          <g key={n.id}>
            <rect x={x - nw / 2} y={y - nh / 2} width={nw} height={nh} rx={2} fill={s.fill} stroke={isSel ? d3.green : s.stroke} strokeWidth={isSel ? 1.8 : 1.1} />
            {!compact && <text x={x - nw / 2 + 9} y={y - nh / 2 + 16} fontSize="8.5" fontFamily={d3.mono} fontWeight="600" letterSpacing="1" fill={n.status === 'locked' ? d3.dim : d3.muted}>{d3Code[n.id]}</text>}
            <text x={x - nw / 2 + 9} y={compact ? y + 3.5 : y + nh / 2 - 9} fontSize={compact ? 8.5 : 10.5} fontFamily={compact ? d3.mono : d3.sans} fontWeight="600" fill={s.text}>
              {compact ? d3Code[n.id] : (n.title.length > 23 ? n.title.slice(0, 22) + '…' : n.title)}
            </text>
          </g>
        );
      })}
    </svg>
  );
}

function D3Tree() {
  return (
    <D3Shell active="tree">
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: 12, height: '100%', position: 'relative' }}>
        <D3Panel title="Certification map — all subteams" pad={0} right={
          <div style={{ display: 'flex', gap: 10 }}>
            {[['CERT', d3.greenDeep], ['ACTIVE', d3.green], ['READY', '#4A5C4C'], ['HOLD', d3.orange], ['LOCKED', '#27302A']].map(([l, c]) => (
              <span key={l} style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                <span style={{ width: 8, height: 8, border: `1.5px solid ${c}`, borderRadius: 1 }}></span>
                <D3Tag color={d3.dim}>{l}</D3Tag>
              </span>
            ))}
          </div>
        }>
          <D3TreeSvg height={742} selected="bandsaw" />
        </D3Panel>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <D3Panel title="Selected node" right={<D3Tag color={d3.green}>MEC-102</D3Tag>}>
            <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 4 }}>Bandsaw Certification</div>
            <D3Tag color={d3.dim}>MECHANICAL · 3 BLOCKS · READY</D3Tag>
            <div style={{ marginTop: 12, fontFamily: d3.mono, fontSize: 10.5, lineHeight: 2, color: d3.muted }}>
              <div><span style={{ color: d3.dim }}>REQ&nbsp;&nbsp;</span>MEC-010 HAND TOOLS <span style={{ color: d3.green }}>✓</span></div>
              <div><span style={{ color: d3.dim }}>OPENS </span>MEC-201 CNC ROUTER</div>
              <div><span style={{ color: d3.dim }}>EST&nbsp;&nbsp;&nbsp;</span>~45 MIN + SHOP DEMO</div>
              <div><span style={{ color: d3.dim }}>AUTH&nbsp;&nbsp;</span>BANDSAW MACHINE QR</div>
            </div>
            <div style={{ marginTop: 14, display: 'inline-flex', background: d3.green, color: '#06130A', fontFamily: d3.mono, fontWeight: 700, fontSize: 12, letterSpacing: '0.06em', padding: '9px 16px', borderRadius: 3 }}>START MODULE ▸</div>
          </D3Panel>
          <D3Panel title="Path stats">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              {[['CERTIFIED', '12'], ['ACTIVE', '2'], ['READY', '3'], ['LOCKED', '7']].map(([l, v]) => (
                <div key={l} style={{ border: `1px solid ${d3.border}`, borderRadius: 3, padding: '10px 12px' }}>
                  <D3Tag color={d3.dim}>{l}</D3Tag>
                  <div style={{ fontFamily: d3.mono, fontSize: 22, fontWeight: 700, marginTop: 2 }}>{v}</div>
                </div>
              ))}
            </div>
            <div style={{ marginTop: 12 }}>
              <D3Tag color={d3.muted}>Critical path to ROBOT INSPECTION</D3Tag>
              <div style={{ marginTop: 6, fontFamily: d3.mono, fontSize: 10, color: d3.muted, lineHeight: 1.9 }}>
                MEC-102 → MEC-201 → MEC-301 → GEN-900<br />
                <span style={{ color: d3.dim }}>4 MODULES REMAIN ON SHORTEST ROUTE</span>
              </div>
            </div>
          </D3Panel>
          <D3Panel title="Bottlenecks · team-wide">
            {[['MEC-101 MILL SAFETY', 6], ['ELE-010 SOLDERING', 4], ['MEC-102 BANDSAW', 3]].map(([m, n]) => (
              <div key={m} style={{ display: 'flex', justifyContent: 'space-between', fontFamily: d3.mono, fontSize: 10.5, padding: '5px 0', borderBottom: `1px solid ${d3.border}` }}>
                <span style={{ color: d3.text }}>{m}</span><span style={{ color: d3.orange }}>{n} WAITING</span>
              </div>
            ))}
          </D3Panel>
        </div>
      </div>
    </D3Shell>
  );
}

// ---------------- Course player ----------------
function D3Player() {
  return (
    <D3Shell active="player">
      <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr 300px', gap: 12, height: '100%', position: 'relative' }}>
        {/* Block timeline */}
        <D3Panel title="MEC-101 · blocks" pad={0}>
          {PLAYER_BLOCKS.map((b, i) => {
            const cur = b.state === 'current', done = b.state === 'done';
            return (
              <div key={i} style={{ display: 'flex', gap: 10, padding: '12px 12px', borderBottom: `1px solid ${d3.border}`, borderLeft: `2px solid ${cur ? d3.green : 'transparent'}`, background: cur ? 'rgba(61,220,116,0.05)' : 'transparent' }}>
                <span style={{ fontFamily: d3.mono, fontSize: 10, color: done ? d3.green : cur ? d3.orange : d3.dim, width: 28 }}>{done ? 'DONE' : cur ? 'LIVE' : '—'}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 12.5, fontWeight: 600, color: b.state === 'upcoming' ? d3.muted : d3.text }}>{String(i + 1).padStart(2, '0')} · {b.title}</div>
                  <D3Tag color={d3.dim}>{b.meta}</D3Tag>
                </div>
              </div>
            );
          })}
          <div style={{ padding: 12 }}>
            <D3Tag color={d3.muted}>Module progress</D3Tag>
            <div style={{ margin: '8px 0 4px' }}><D3Meter pct={50} segments={4} /></div>
            <D3Tag color={d3.dim}>2/4 BLOCKS · QUIZ IN PROGRESS</D3Tag>
          </div>
        </D3Panel>

        {/* Quiz console */}
        <D3Panel title="Quiz · mill safety" right={<D3Tag color={d3.orange}>CHECK 03/07</D3Tag>} pad={20}>
          <div style={{ display: 'flex', gap: 3, marginBottom: 18 }}>
            {Array.from({ length: 7 }, (_, i) => (
              <span key={i} style={{ flex: 1, height: 4, background: i < 2 ? d3.green : i === 2 ? d3.orange : '#1C231B', borderRadius: 1 }}></span>
            ))}
          </div>
          <p style={{ margin: '0 0 18px', fontSize: 17, fontWeight: 700, lineHeight: 1.4, fontFamily: d3.sans }}>{QUIZ_QUESTION.q}</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
            {QUIZ_QUESTION.options.map((o, i) => {
              const picked = i === QUIZ_QUESTION.picked;
              return (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px', borderRadius: 3, border: `1px solid ${picked ? d3.green : d3.border}`, background: picked ? 'rgba(61,220,116,0.07)' : d3.panel2 }}>
                  <span style={{ fontFamily: d3.mono, fontSize: 11, fontWeight: 700, color: picked ? d3.green : d3.dim, width: 16 }}>{String.fromCharCode(65 + i)}</span>
                  <span style={{ fontSize: 13.5, color: picked ? d3.text : d3.muted }}>{o}</span>
                  {picked && <span style={{ marginLeft: 'auto', color: d3.green }}>{Icon.check(14)}</span>}
                </div>
              );
            })}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 20, paddingTop: 16, borderTop: `1px solid ${d3.border}` }}>
            <span style={{ background: d3.green, color: '#06130A', fontFamily: d3.mono, fontWeight: 700, fontSize: 12, letterSpacing: '0.06em', padding: '10px 18px', borderRadius: 3 }}>LOCK ANSWER ▸</span>
            <D3Tag color={d3.dim}>PASS ≥ 80% · ATTEMPT 1/3 · NO TIME LIMIT</D3Tag>
          </div>
        </D3Panel>

        {/* Module data */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <D3Panel title="Module data">
            <div style={{ fontFamily: d3.mono, fontSize: 10.5, lineHeight: 2.1, color: d3.muted }}>
              <div><span style={{ color: d3.dim }}>CODE&nbsp;&nbsp;&nbsp;</span>MEC-101</div>
              <div><span style={{ color: d3.dim }}>TEAM&nbsp;&nbsp;&nbsp;</span>MECHANICAL</div>
              <div><span style={{ color: d3.dim }}>REQ&nbsp;&nbsp;&nbsp;&nbsp;</span>MEC-010 <span style={{ color: d3.green }}>✓</span></div>
              <div><span style={{ color: d3.dim }}>OPENS&nbsp;&nbsp;</span>MEC-103 LATHE</div>
              <div><span style={{ color: d3.dim }}>AUTH&nbsp;&nbsp;&nbsp;</span>VERTICAL MILL QR</div>
            </div>
          </D3Panel>
          <D3Panel title="Checkoff spec — block 04">
            <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
              {CHECKLIST.map((c, i) => (
                <div key={i} style={{ display: 'flex', gap: 8, fontSize: 11.5, color: d3.muted, lineHeight: 1.45 }}>
                  <span style={{ fontFamily: d3.mono, fontSize: 10, color: d3.dim }}>{String(i + 1).padStart(2, '0')}</span>{c}
                </div>
              ))}
            </div>
            <div style={{ marginTop: 12, borderTop: `1px solid ${d3.border}`, paddingTop: 10 }}>
              <D3Tag color={d3.dim}>MENTOR SCANS YOUR PASSPORT TO APPROVE</D3Tag>
            </div>
          </D3Panel>
        </div>
      </div>
    </D3Shell>
  );
}

Object.assign(window, { D3Dashboard, D3Player, D3Tree });
