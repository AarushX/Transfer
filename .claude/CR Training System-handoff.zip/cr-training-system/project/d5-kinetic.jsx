// ============================================================
// D5 — KINETIC (experimental · dark)
// "From potential to kinetic." Big type, diagonal energy,
// circuit traces, oversized progress. Most brand-forward.
// ============================================================

const d5 = {
  bg: '#070908',
  panel: '#0E120F',
  border: '#1E2620',
  text: '#EFF6F0',
  muted: '#93A597',
  dim: '#5A6B5E',
  green: '#2FE066',
  greenDeep: '#0E6B22',
  orange: '#E8842A',
  black: "'Archivo Black', sans-serif",
  sans: "'Archivo', sans-serif",
  mono: "'JetBrains Mono', monospace",
};

const SKEW = 'skewX(-12deg)';

function D5SkewBar({ pct, color = d5.green, h = 12, w = '100%' }) {
  return (
    <div style={{ width: w, height: h, transform: SKEW, background: '#181F19', overflow: 'hidden' }}>
      <div style={{ width: pct + '%', height: '100%', background: color, boxShadow: `0 0 20px ${color}66` }}></div>
    </div>
  );
}

function D5Btn({ children, ghost }) {
  return (
    <span style={{ display: 'inline-block', transform: SKEW, background: ghost ? 'transparent' : d5.green, border: `2px solid ${d5.green}`, padding: '10px 22px' }}>
      <span style={{ display: 'inline-block', transform: 'skewX(12deg)', fontFamily: d5.mono, fontWeight: 700, fontSize: 12, letterSpacing: '0.1em', color: ghost ? d5.green : '#05130A' }}>{children}</span>
    </span>
  );
}

// decorative circuit trace
function D5Trace({ style, color = 'rgba(47,224,102,0.25)' }) {
  return (
    <svg width="320" height="120" viewBox="0 0 320 120" style={{ position: 'absolute', pointerEvents: 'none', ...style }}>
      <path d="M 0 100 H 90 L 130 60 H 200 L 230 30 H 320" fill="none" stroke={color} strokeWidth="1.5" />
      <path d="M 0 116 H 110 L 150 76 H 240 L 264 52 H 320" fill="none" stroke={color} strokeWidth="1.5" opacity="0.5" />
      <circle cx="90" cy="100" r="3" fill="none" stroke={color} strokeWidth="1.5" />
      <circle cx="200" cy="60" r="3" fill="none" stroke={color} strokeWidth="1.5" />
      <circle cx="230" cy="30" r="3" fill={color} />
    </svg>
  );
}

function D5Shell({ children, active }) {
  const nav = [['dash', Icon.home(17)], ['player', Icon.grid(17)], ['tree', Icon.tree(17)], [null, Icon.scan(17)], [null, Icon.award(17)]];
  return (
    <div className="ab" style={{ background: d5.bg, color: d5.text, fontFamily: d5.sans, display: 'flex' }}>
      {/* Vertical rail */}
      <aside style={{ width: 68, flexShrink: 0, borderRight: `1px solid ${d5.border}`, display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '16px 0', position: 'relative', zIndex: 2 }}>
        <img src="brand/torm.png" alt="" style={{ width: 32, height: 30, objectFit: 'contain', marginBottom: 22 }} />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {nav.map(([key, ic], i) => {
            const a = key === active;
            return (
              <span key={i} style={{ width: 40, height: 40, display: 'grid', placeItems: 'center', color: a ? '#05130A' : d5.dim, background: a ? d5.green : 'transparent', transform: a ? SKEW : 'none' }}>
                <span style={{ transform: a ? 'skewX(12deg)' : 'none', display: 'flex' }}>{ic}</span>
              </span>
            );
          })}
        </div>
        <div style={{ flex: 1 }}></div>
        <div style={{ writingMode: 'vertical-rl', transform: 'rotate(180deg)', fontFamily: d5.mono, fontSize: 10, letterSpacing: '0.34em', color: d5.dim, whiteSpace: 'nowrap' }}>FROM POTENTIAL TO KINETIC</div>
        <div style={{ width: 36, height: 36, marginTop: 14, background: d5.greenDeep, color: '#fff', display: 'grid', placeItems: 'center', fontFamily: d5.mono, fontWeight: 700, fontSize: 12 }}>AS</div>
      </aside>
      <main style={{ flex: 1, position: 'relative', minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        {/* ticker */}
        <div style={{ height: 34, flexShrink: 0, borderBottom: `1px solid ${d5.border}`, display: 'flex', alignItems: 'center', gap: 26, padding: '0 24px', fontFamily: d5.mono, fontSize: 10.5, letterSpacing: '0.1em', color: d5.muted, overflow: 'hidden', whiteSpace: 'nowrap' }}>
          <span style={{ color: d5.green }}>● SHOP OPEN</span>
          <span>SESSION 02:14:09</span>
          <span>HOURS 23.5/40</span>
          <span style={{ color: d5.orange }}>3 CHECKOFFS WAITING ON YOU</span>
          <span>NEXT COMP: PEACHTREE REGIONAL · 26 DAYS</span>
          <span style={{ color: d5.dim }}>12 MODULES CERTIFIED</span>
        </div>
        <div style={{ flex: 1, position: 'relative', padding: '26px 32px', minHeight: 0 }}>{children}</div>
      </main>
    </div>
  );
}

// ---------------- Dashboard ----------------
function D5Dashboard() {
  return (
    <D5Shell active="dash">
      <D5Trace style={{ right: 0, top: 0 }} />
      {/* Hero */}
      <div style={{ marginBottom: 24, position: 'relative' }}>
        <div style={{ fontFamily: d5.mono, fontSize: 11, letterSpacing: '0.3em', color: d5.green, marginBottom: 8 }}>WEDNESDAY · BUILD WEEK −12</div>
        <h1 style={{ margin: 0, fontFamily: d5.black, fontSize: 46, lineHeight: 0.98, textTransform: 'uppercase', letterSpacing: '-0.01em' }}>
          Aarush, you're<br /><span style={{ color: d5.green }}>64% to a letter.</span>
        </h1>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr 1fr', gap: 14, alignItems: 'stretch' }}>
        {/* Active module — oversized */}
        <div style={{ gridRow: '1 / 3', background: d5.panel, border: `1px solid ${d5.border}`, padding: '22px 24px', position: 'relative', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', right: -30, top: -28, fontFamily: d5.black, fontSize: 170, color: 'rgba(47,224,102,0.07)', lineHeight: 1 }}>50</div>
          <div style={{ fontFamily: d5.mono, fontSize: 10.5, letterSpacing: '0.22em', color: d5.muted }}>ACTIVE MODULE · MECHANICAL</div>
          <div style={{ fontFamily: d5.black, fontSize: 27, textTransform: 'uppercase', lineHeight: 1.05, margin: '10px 0 4px' }}>Mill Safety<br />& Operation</div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, margin: '18px 0 8px' }}>
            <span style={{ fontFamily: d5.black, fontSize: 58, lineHeight: 1, color: d5.green }}>50<span style={{ fontSize: 26 }}>%</span></span>
            <span style={{ fontFamily: d5.mono, fontSize: 11, color: d5.dim }}>2/4 BLOCKS</span>
          </div>
          <D5SkewBar pct={50} h={14} />
          <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 7 }}>
            {PLAYER_BLOCKS.map((b, i) => (
              <div key={i} style={{ display: 'flex', gap: 10, fontFamily: d5.mono, fontSize: 11, alignItems: 'center' }}>
                <span style={{ color: b.state === 'done' ? d5.green : b.state === 'current' ? d5.orange : d5.dim }}>{b.state === 'done' ? '▰' : b.state === 'current' ? '▶' : '▱'}</span>
                <span style={{ color: b.state === 'upcoming' ? d5.dim : d5.text }}>{b.title.toUpperCase()}</span>
              </div>
            ))}
          </div>
          <div style={{ marginTop: 20 }}><D5Btn>RESUME ▸</D5Btn></div>
        </div>

        {/* Hours */}
        <div style={{ background: d5.panel, border: `1px solid ${d5.border}`, padding: '18px 20px', position: 'relative' }}>
          <div style={{ fontFamily: d5.mono, fontSize: 10.5, letterSpacing: '0.22em', color: d5.muted }}>SEASON HOURS</div>
          <div style={{ fontFamily: d5.black, fontSize: 44, lineHeight: 1, margin: '10px 0 8px' }}>23.5<span style={{ fontSize: 18, color: d5.dim }}>/40</span></div>
          <D5SkewBar pct={59} />
        </div>

        {/* Checkoffs waiting */}
        <div style={{ background: d5.panel, border: `1px solid ${d5.orange}55`, padding: '18px 20px' }}>
          <div style={{ fontFamily: d5.mono, fontSize: 10.5, letterSpacing: '0.22em', color: d5.orange }}>MENTOR QUEUE · YOU</div>
          <div style={{ fontFamily: d5.black, fontSize: 44, lineHeight: 1, margin: '10px 0 8px', color: d5.orange }}>3</div>
          <div style={{ fontFamily: d5.mono, fontSize: 10.5, color: d5.muted, lineHeight: 1.8 }}>R.CHEN · ELE-010<br />M.OKAFOR · MEC-102<br />J.PARK · MEC-101</div>
        </div>

        {/* Passport */}
        <div style={{ background: d5.panel, border: `1px solid ${d5.border}`, padding: '18px 20px', display: 'flex', gap: 16, gridColumn: '2 / 4' }}>
          <div style={{ background: '#fff', padding: 7, alignSelf: 'center' }}><FakeQR size={92} /></div>
          <div style={{ alignSelf: 'center' }}>
            <div style={{ fontFamily: d5.mono, fontSize: 10.5, letterSpacing: '0.22em', color: d5.muted }}>PASSPORT · CR-0427</div>
            <div style={{ fontFamily: d5.black, fontSize: 19, textTransform: 'uppercase', margin: '6px 0 4px' }}>Aarush Sharma</div>
            <div style={{ fontFamily: d5.mono, fontSize: 10.5, color: d5.dim }}>AUTH: MILL · BANDSAW · 3DP — SCAN FOR CHECKOFF / MACHINE / ATTENDANCE</div>
          </div>
        </div>
      </div>

      {/* Up next — kinetic tiles */}
      <div style={{ marginTop: 22 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 14, marginBottom: 12 }}>
          <span style={{ fontFamily: d5.black, fontSize: 19, textTransform: 'uppercase', letterSpacing: '0.02em' }}>Up next</span>
          <span style={{ flex: 1, height: 1, background: d5.border }}></span>
          <span style={{ fontFamily: d5.mono, fontSize: 10.5, color: d5.green, letterSpacing: '0.12em' }}>ALL COURSEWORK ▸</span>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10 }}>
          {COURSES.slice(0, 5).map((c, i) => (
            <div key={i} style={{ border: `1px solid ${i === 0 ? d5.green + '88' : d5.border}`, background: i === 0 ? 'rgba(47,224,102,0.05)' : d5.panel, padding: '13px 14px', position: 'relative', overflow: 'hidden', minHeight: 108 }}>
              <div style={{ position: 'absolute', right: 4, bottom: -16, fontFamily: d5.black, fontSize: 64, color: 'rgba(239,246,240,0.05)', lineHeight: 1 }}>{String(i + 1).padStart(2, '0')}</div>
              <div style={{ fontFamily: d5.mono, fontSize: 9, letterSpacing: '0.18em', color: c.team === 'Electrical' ? d5.orange : c.team === 'Programming' ? '#7FC8A9' : d5.green }}>{c.team.toUpperCase()}</div>
              <div style={{ fontWeight: 700, fontSize: 13.5, lineHeight: 1.25, margin: '7px 0' }}>{c.title}</div>
              <div style={{ fontFamily: d5.mono, fontSize: 9.5, color: d5.dim }}>{c.status === 'in_progress' ? `${c.done}/${c.total} BLOCKS` : 'READY'}</div>
            </div>
          ))}
        </div>
      </div>
    </D5Shell>
  );
}

// ---------------- Course player ----------------
function D5Player() {
  return (
    <D5Shell active="player">
      <D5Trace style={{ right: 0, bottom: 0, transform: 'scaleY(-1)' }} />
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 24, marginBottom: 20 }}>
        <div>
          <div style={{ fontFamily: d5.mono, fontSize: 10.5, letterSpacing: '0.3em', color: d5.green, marginBottom: 6 }}>MEC-101 · MECHANICAL · BLOCK 3 OF 4</div>
          <h1 style={{ margin: 0, fontFamily: d5.black, fontSize: 38, lineHeight: 1, textTransform: 'uppercase' }}>Mill Safety & Operation</h1>
        </div>
        <span style={{ flex: 1 }}></span>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontFamily: d5.black, fontSize: 40, lineHeight: 1, color: d5.green }}>03<span style={{ color: d5.dim, fontSize: 22 }}>/07</span></div>
          <div style={{ fontFamily: d5.mono, fontSize: 9.5, letterSpacing: '0.2em', color: d5.dim }}>QUIZ QUESTION</div>
        </div>
      </div>

      {/* block rail */}
      <div style={{ display: 'flex', gap: 6, marginBottom: 22 }}>
        {PLAYER_BLOCKS.map((b, i) => {
          const done = b.state === 'done', cur = b.state === 'current';
          return (
            <div key={i} style={{ flex: 1, transform: SKEW, background: done ? d5.greenDeep : cur ? d5.green : '#141A15', height: 32, display: 'grid', placeItems: 'center' }}>
              <span style={{ transform: 'skewX(12deg)', fontFamily: d5.mono, fontSize: 10, fontWeight: 700, letterSpacing: '0.1em', color: cur ? '#05130A' : done ? '#C9F3D6' : d5.dim }}>
                {String(i + 1).padStart(2, '0')} {b.type.toUpperCase()} {done && '✓'}
              </span>
            </div>
          );
        })}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: 18 }}>
        <div style={{ position: 'relative' }}>
          <p style={{ margin: '0 0 18px', fontFamily: d5.black, fontSize: 24, lineHeight: 1.3, textTransform: 'none' }}>{QUIZ_QUESTION.q}</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
            {QUIZ_QUESTION.options.map((o, i) => {
              const picked = i === QUIZ_QUESTION.picked;
              return (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 0, border: `1px solid ${picked ? d5.green : d5.border}`, background: picked ? 'rgba(47,224,102,0.07)' : d5.panel }}>
                  <span style={{ width: 52, alignSelf: 'stretch', display: 'grid', placeItems: 'center', fontFamily: d5.black, fontSize: 19, color: picked ? '#05130A' : d5.dim, background: picked ? d5.green : '#141A15' }}>{String.fromCharCode(65 + i)}</span>
                  <span style={{ padding: '14px 18px', fontSize: 14.5, color: picked ? d5.text : d5.muted, fontWeight: picked ? 700 : 400 }}>{o}</span>
                </div>
              );
            })}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginTop: 22 }}>
            <D5Btn>LOCK IT IN ▸</D5Btn>
            <span style={{ fontFamily: d5.mono, fontSize: 10.5, letterSpacing: '0.1em', color: d5.dim }}>PASS ≥ 80% · ATTEMPT 1/3</span>
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div style={{ background: d5.panel, border: `1px solid ${d5.border}`, padding: '16px 18px' }}>
            <div style={{ fontFamily: d5.mono, fontSize: 10, letterSpacing: '0.22em', color: d5.muted, marginBottom: 10 }}>QUIZ TELEMETRY</div>
            <div style={{ display: 'flex', gap: 4 }}>
              {Array.from({ length: 7 }, (_, i) => (
                <span key={i} style={{ flex: 1, height: 26, transform: SKEW, background: i < 2 ? d5.greenDeep : i === 2 ? d5.green : '#141A15' }}></span>
              ))}
            </div>
            <div style={{ marginTop: 8, fontFamily: d5.mono, fontSize: 9.5, color: d5.dim }}>2 CORRECT · 1 LIVE · 4 AHEAD</div>
          </div>
          <div style={{ background: d5.panel, border: `1px solid ${d5.border}`, padding: '16px 18px', flex: 1 }}>
            <div style={{ fontFamily: d5.mono, fontSize: 10, letterSpacing: '0.22em', color: d5.muted, marginBottom: 10 }}>NEXT: SHOP DEMO</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {CHECKLIST.slice(0, 4).map((c, i) => (
                <div key={i} style={{ display: 'flex', gap: 9, fontSize: 11.5, color: d5.muted, lineHeight: 1.4 }}>
                  <span style={{ fontFamily: d5.mono, fontSize: 10, color: d5.green }}>{String(i + 1).padStart(2, '0')}</span>{c}
                </div>
              ))}
            </div>
            <div style={{ marginTop: 14, paddingTop: 12, borderTop: `1px solid ${d5.border}`, fontFamily: d5.mono, fontSize: 9.5, color: d5.dim, letterSpacing: '0.08em' }}>MENTOR SCANS YOUR PASSPORT TO CERTIFY</div>
          </div>
        </div>
      </div>
    </D5Shell>
  );
}

// ---------------- Skill tree (trace map) ----------------
function d5NodeGlow(status) {
  switch (status) {
    case 'completed': return { fill: d5.greenDeep, ring: d5.greenDeep, text: d5.text, glow: 'rgba(14,107,34,0.5)' };
    case 'in_progress': return { fill: d5.green, ring: d5.green, text: d5.text, glow: 'rgba(47,224,102,0.6)' };
    case 'available': return { fill: '#0E120F', ring: '#5A6B5E', text: d5.text, glow: 'none' };
    case 'pending': return { fill: d5.orange, ring: d5.orange, text: d5.text, glow: 'rgba(232,132,42,0.5)' };
    default: return { fill: '#0B0E0C', ring: '#27302A', text: d5.dim, glow: 'none' };
  }
}

function D5Tree() {
  const W = 1240, H = 700, mx = 110, my = 70;
  const px = (x) => mx + (x / 100) * (W - mx * 2);
  const py = (y) => my + (y / 100) * (H - my * 2);
  const byId = Object.fromEntries(TREE_NODES.map((n) => [n.id, n]));
  return (
    <D5Shell active="tree">
      <div style={{ position: 'absolute', left: 18, bottom: 8, fontFamily: d5.black, fontSize: 110, color: 'rgba(47,224,102,0.05)', textTransform: 'uppercase', pointerEvents: 'none', letterSpacing: '-0.02em' }}>Trace Map</div>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 18, marginBottom: 8 }}>
        <h1 style={{ margin: 0, fontFamily: d5.black, fontSize: 34, textTransform: 'uppercase', lineHeight: 1 }}>Your trace map</h1>
        <span style={{ fontFamily: d5.mono, fontSize: 10.5, color: d5.muted, letterSpacing: '0.12em', paddingBottom: 4 }}>EVERY CERT ROUTES TO COMP-READY</span>
        <span style={{ flex: 1 }}></span>
        {[['CERTIFIED', d5.greenDeep], ['LIVE', d5.green], ['READY', '#5A6B5E'], ['HOLD', d5.orange]].map(([l, c]) => (
          <span key={l} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontFamily: d5.mono, fontSize: 9.5, color: d5.muted, letterSpacing: '0.1em', paddingBottom: 4 }}>
            <span style={{ width: 9, height: 9, borderRadius: 99, background: c, boxShadow: `0 0 8px ${c}` }}></span>{l}
          </span>
        ))}
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', height: 'calc(100% - 60px)', display: 'block' }}>
        {/* traces */}
        {TREE_EDGES.map(([a, b], i) => {
          const A = byId[a], B = byId[b];
          const x1 = px(A.x), y1 = py(A.y), x2 = px(B.x), y2 = py(B.y);
          const lit = A.status === 'completed';
          const mid = x1 + (x2 - x1) * 0.5;
          return (
            <g key={i}>
              <path d={`M ${x1} ${y1} H ${mid - Math.abs(y2 - y1) * 0.35} L ${mid + Math.abs(y2 - y1) * 0.35} ${y2} H ${x2}`} fill="none" stroke={lit ? d5.green : '#222B24'} strokeWidth={lit ? 2 : 1.2} opacity={lit ? 0.8 : 1} />
              {lit && <path d={`M ${x1} ${y1} H ${mid - Math.abs(y2 - y1) * 0.35} L ${mid + Math.abs(y2 - y1) * 0.35} ${y2} H ${x2}`} fill="none" stroke={d5.green} strokeWidth="6" opacity="0.12" />}
            </g>
          );
        })}
        {/* nodes as glowing pads */}
        {TREE_NODES.map((n) => {
          const s = d5NodeGlow(n.status);
          const x = px(n.x), y = py(n.y);
          const cur = n.status === 'in_progress';
          return (
            <g key={n.id}>
              {s.glow !== 'none' && <circle cx={x} cy={y} r={16} fill={s.glow} opacity="0.35" />}
              <circle cx={x} cy={y} r={cur ? 10 : 7.5} fill={s.fill} stroke={s.ring} strokeWidth="2" />
              {n.status === 'completed' && <path d={`M ${x - 3.5} ${y} l 2.5 3 l 5 -5.5`} stroke="#C9F3D6" strokeWidth="2" fill="none" strokeLinecap="round" />}
              <text x={x} y={y - 16} textAnchor="middle" fontSize="11.5" fontFamily={d5.sans} fontWeight="700" fill={s.text}>{n.title.length > 24 ? n.title.slice(0, 23) + '…' : n.title}</text>
              <text x={x} y={y + 26} textAnchor="middle" fontSize="8.5" fontFamily={d5.mono} letterSpacing="1.5" fill={d5.dim}>{n.team.toUpperCase()}</text>
            </g>
          );
        })}
        {/* terminal */}
        <g transform={`translate(${px(92)}, ${py(52)})`}>
          <circle cx="0" cy="0" r="22" fill="none" stroke={d5.green} strokeWidth="1" strokeDasharray="3 4" opacity="0.6" />
        </g>
      </svg>
      {/* selected node card */}
      <div style={{ position: 'absolute', right: 30, bottom: 26, width: 270, background: d5.panel, border: `1px solid ${d5.green}66`, padding: '16px 18px' }}>
        <div style={{ fontFamily: d5.mono, fontSize: 9.5, letterSpacing: '0.22em', color: d5.green }}>SELECTED · READY</div>
        <div style={{ fontFamily: d5.black, fontSize: 19, textTransform: 'uppercase', margin: '7px 0 4px' }}>Bandsaw Certification</div>
        <div style={{ fontFamily: d5.mono, fontSize: 10, color: d5.muted, lineHeight: 1.8 }}>REQ HAND TOOLS ✓ · OPENS CNC ROUTER<br />3 BLOCKS · ~45 MIN + DEMO</div>
        <div style={{ marginTop: 12 }}><D5Btn>START ▸</D5Btn></div>
      </div>
    </D5Shell>
  );
}

Object.assign(window, { D5Dashboard, D5Player, D5Tree });
