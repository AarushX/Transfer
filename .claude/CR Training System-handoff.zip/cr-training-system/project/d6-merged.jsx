// ============================================================
// D6 — CLEAN LMS (merged · main direction)
// Base: Clean LMS shell, palette, type (calm light surfaces).
// Course player: Pit Wall's dense 3-column structure, re-skinned.
// Skill tree: Field Manual's boxy/squared nodes, light theme.
// ============================================================

const d6 = {
  bg: '#F4F6F3',
  card: '#FFFFFF',
  border: '#E2E7E0',
  text: '#1A211C',
  muted: '#5C6B60',
  dim: '#8B988E',
  green: '#1E9E4C',
  greenDark: '#0E6B22',
  greenSoft: '#E7F6EC',
  orange: '#C95F00',
  orangeSoft: '#FBEFE2',
  font: "'Atkinson Hyperlegible', sans-serif",
  mono: "'JetBrains Mono', monospace",
};

const d6TeamColor = { Mechanical: '#1E9E4C', Electrical: '#C95F00', Programming: '#3E7A8C', General: '#8B988E' };

function D6Card({ children, style, pad = 18 }) {
  return <div style={{ background: d6.card, border: `1px solid ${d6.border}`, borderRadius: 12, padding: pad, boxShadow: '0 1px 2px rgba(26,33,28,0.04)', ...style }}>{children}</div>;
}

function D6Label({ children, style }) {
  return <p style={{ margin: 0, fontSize: 11, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: d6.dim, ...style }}>{children}</p>;
}

function D6NavItem({ icon, label, active, badge }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px', borderRadius: 8, fontSize: 14, fontWeight: active ? 700 : 400, color: active ? d6.greenDark : d6.muted, background: active ? d6.greenSoft : 'transparent' }}>
      <span style={{ display: 'flex', color: active ? d6.green : d6.dim }}>{icon}</span>
      <span style={{ flex: 1 }}>{label}</span>
      {badge && <span style={{ fontSize: 11, fontWeight: 700, background: d6.orangeSoft, color: d6.orange, borderRadius: 999, padding: '1px 8px' }}>{badge}</span>}
    </div>
  );
}

function D6Shell({ children, active }) {
  return (
    <div className="ab" style={{ background: d6.bg, color: d6.text, fontFamily: d6.font, display: 'flex', flexDirection: 'column' }}>
      {/* Top bar */}
      <header style={{ height: 56, background: d6.card, borderBottom: `1px solid ${d6.border}`, display: 'flex', alignItems: 'center', gap: 16, padding: '0 20px', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, width: 212 }}>
          <img src="brand/torm.png" alt="" style={{ width: 26, height: 24, objectFit: 'contain' }} />
          <span style={{ fontWeight: 700, fontSize: 15 }}>CircuitRunners</span>
        </div>
        <div style={{ flex: 1, maxWidth: 420, display: 'flex', alignItems: 'center', gap: 8, background: d6.bg, border: `1px solid ${d6.border}`, borderRadius: 8, padding: '7px 12px', fontSize: 13, color: d6.dim }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="7" /><line x1="21" y1="21" x2="16.5" y2="16.5" /></svg>
          Search courses, people, machines…
        </div>
        <div style={{ flex: 1 }}></div>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 12.5, fontWeight: 700, color: d6.greenDark, background: d6.greenSoft, borderRadius: 999, padding: '5px 12px' }}>● Checked in · 2h 14m</span>
        <div style={{ width: 34, height: 34, borderRadius: 999, background: d6.greenDark, color: '#fff', display: 'grid', placeItems: 'center', fontWeight: 700, fontSize: 13 }}>AS</div>
      </header>
      <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
        {/* Sidebar */}
        <aside style={{ width: 212, flexShrink: 0, padding: '16px 12px', borderRight: `1px solid ${d6.border}`, background: d6.card, display: 'flex', flexDirection: 'column', gap: 2 }}>
          <D6NavItem icon={Icon.home(15)} label="Dashboard" active={active === 'dash'} />
          <D6NavItem icon={Icon.grid(15)} label="Coursework" active={active === 'player'} />
          <D6NavItem icon={Icon.tree(15)} label="Skill map" active={active === 'tree'} />
          <D6NavItem icon={Icon.scan(15)} label="Scan" />
          <D6NavItem icon={Icon.award(15)} label="Season" />
          <D6Label style={{ margin: '16px 0 6px', paddingLeft: 12 }}>Mentor</D6Label>
          <D6NavItem icon={Icon.check(15)} label="Checkoffs" badge="3" />
          <D6NavItem icon={Icon.wrench(15)} label="Machines" />
          <D6NavItem icon={Icon.user(15)} label="Roster" />
        </aside>
        <main style={{ flex: 1, padding: '24px 28px', minWidth: 0 }}>{children}</main>
      </div>
    </div>
  );
}

function D6Bar({ pct, color = d6.green, h = 6 }) {
  return (
    <div style={{ height: h, borderRadius: 999, background: '#EDF0EC', overflow: 'hidden' }}>
      <div style={{ width: pct + '%', height: '100%', borderRadius: 999, background: color }}></div>
    </div>
  );
}

function D6StatusChip({ status }) {
  const map = {
    in_progress: ['In progress', d6.greenSoft, d6.greenDark],
    ready: ['Ready to start', '#F0F2EF', d6.muted],
    pending: ['Awaiting mentor', d6.orangeSoft, d6.orange],
  };
  const [label, bg, color] = map[status] || map.ready;
  return <span style={{ fontSize: 11.5, fontWeight: 700, background: bg, color, borderRadius: 999, padding: '3px 10px', whiteSpace: 'nowrap' }}>{label}</span>;
}

// ---------------- Dashboard (Clean LMS) ----------------
function D6Dashboard() {
  const stats = [
    ['Modules certified', '12', null],
    ['In progress', '2', null],
    ['Hours this season', '23.5', 'of 40'],
    ['Lettering', '64%', '2 of 5 reqs'],
  ];
  return (
    <D6Shell active="dash">
      <h1 style={{ margin: 0, fontSize: 24, fontWeight: 700 }}>Welcome back, Aarush</h1>
      <p style={{ margin: '4px 0 18px', fontSize: 13.5, color: d6.muted }}>Wednesday, June 10 · Build season is 12 weeks out — keep your certifications moving.</p>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 16 }}>
        {stats.map(([l, v, s]) => (
          <D6Card key={l} pad={16}>
            <D6Label>{l}</D6Label>
            <p style={{ margin: '6px 0 0', fontSize: 26, fontWeight: 700 }}>{v} {s && <span style={{ fontSize: 12, fontWeight: 400, color: d6.dim }}>{s}</span>}</p>
          </D6Card>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: 16 }}>
        <D6Card pad={0}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 18px', borderBottom: `1px solid ${d6.border}` }}>
            <h2 style={{ margin: 0, fontSize: 15.5, fontWeight: 700 }}>Up next</h2>
            <span style={{ fontSize: 13, color: d6.green, fontWeight: 700 }}>View all coursework →</span>
          </div>
          {COURSES.slice(0, 7).map((c, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 18px', borderBottom: i < 6 ? `1px solid ${d6.border}` : 'none' }}>
              <span style={{ width: 8, height: 8, borderRadius: 99, background: d6TeamColor[c.team], flexShrink: 0 }}></span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 700 }}>{c.title}</div>
                <div style={{ fontSize: 12, color: d6.dim }}>{c.team} · {c.total} blocks</div>
              </div>
              {c.status === 'in_progress' && <div style={{ width: 120 }}><D6Bar pct={(c.done / c.total) * 100} h={5} /></div>}
              <D6StatusChip status={c.status} />
              <span style={{ color: d6.dim }}>{Icon.arrowR(14)}</span>
            </div>
          ))}
        </D6Card>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <D6Card style={{ textAlign: 'center' }}>
            <D6Label>Student ID</D6Label>
            <div style={{ display: 'grid', placeItems: 'center', margin: '10px 0 6px' }}>
              <div style={{ border: `1px solid ${d6.border}`, borderRadius: 10, padding: 8 }}><FakeQR size={108} /></div>
            </div>
            <p style={{ margin: 0, fontSize: 11.5, color: d6.dim }}>Show to a mentor for checkoffs,<br />machines & attendance</p>
          </D6Card>
          <D6Card>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <D6Label>Lettering progress</D6Label>
              <span style={{ fontFamily: d6.mono, fontSize: 13, fontWeight: 700, color: d6.greenDark }}>64%</span>
            </div>
            <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 9 }}>
              {[['Outreach hours', 80, true], ['Shop hours', 59, false], ['Competition', 100, true], ['Parent volunteer', 20, false]].map(([l, p, met]) => (
                <div key={l}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 3 }}>
                    <span style={{ color: d6.muted }}>{l}</span>
                    <span style={{ color: met ? d6.green : d6.dim, fontWeight: 700 }}>{met ? '✓' : p + '%'}</span>
                  </div>
                  <D6Bar pct={p} h={4} color={met ? d6.green : '#9DBBA6'} />
                </div>
              ))}
            </div>
          </D6Card>
        </div>
      </div>
    </D6Shell>
  );
}

// ---------------- Course player (Field Manual work-order · Clean LMS skin) ----------------
function D6Player() {
  return (
    <D6Shell active="player">
      <p style={{ margin: 0, fontSize: 12.5, color: d6.dim }}>Coursework / <strong style={{ color: d6.muted }}>Mill Safety & Operation</strong></p>

      {/* Work-order header — title + spec columns */}
      <D6Card pad={0} style={{ overflow: 'hidden', margin: '8px 0 16px' }}>
        <div style={{ display: 'flex' }}>
          <div style={{ flex: 1, padding: '14px 18px', borderRight: `1px solid ${d6.border}` }}>
            <D6Label>Work order · module</D6Label>
            <div style={{ fontSize: 23, fontWeight: 700, lineHeight: 1.1, marginTop: 4 }}>Mill Safety &amp; Operation</div>
          </div>
          {[['CODE', 'MEC-101', d6.text], ['SUBTEAM', 'MECHANICAL', d6.text], ['PREREQ', 'HAND TOOLS ✓', d6.green], ['STATUS', 'IN PROGRESS', d6.orange]].map(([l, v, c], i) => (
            <div key={l} style={{ padding: '14px 16px', borderRight: i < 3 ? `1px solid ${d6.border}` : 'none', minWidth: 116 }}>
              <D6Label>{l}</D6Label>
              <div style={{ fontFamily: d6.mono, fontSize: 12.5, fontWeight: 700, marginTop: 7, color: c }}>{v}</div>
            </div>
          ))}
        </div>
        {/* Procedure-step tracker (the "top checking" row) */}
        <div style={{ display: 'flex', borderTop: `1px solid ${d6.border}` }}>
          {PLAYER_BLOCKS.map((b, i) => {
            const cur = b.state === 'current', done = b.state === 'done';
            return (
              <div key={i} style={{ flex: 1, padding: '12px 14px', borderRight: i < 3 ? `1px solid ${d6.border}` : 'none', background: cur ? d6.greenSoft : '#fff', opacity: b.state === 'upcoming' ? 0.62 : 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ width: 18, height: 18, borderRadius: 5, border: `2px solid ${done ? d6.green : cur ? d6.green : d6.dim}`, background: done ? d6.green : '#fff', display: 'grid', placeItems: 'center', color: '#fff', flexShrink: 0 }}>{done && Icon.check(10)}</span>
                  <span style={{ fontFamily: d6.mono, fontSize: 11, fontWeight: 700, color: cur ? d6.greenDark : d6.text }}>{i + 1}.0 {b.type.toUpperCase()}</span>
                  {cur && <span style={{ fontFamily: d6.mono, fontSize: 9, color: d6.orange, fontWeight: 700, marginLeft: 'auto' }}>← YOU ARE HERE</span>}
                </div>
                <div style={{ fontSize: 11.5, color: d6.muted, marginTop: 5 }}>{b.title}</div>
              </div>
            );
          })}
        </div>
      </D6Card>

      {/* Full-width knowledge-check field form + mentor sign-off */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: 16, alignItems: 'start' }}>
        <D6Card pad={24}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', borderBottom: `1px solid ${d6.border}`, paddingBottom: 12, marginBottom: 16 }}>
            <h2 style={{ margin: 0, fontSize: 17, fontWeight: 700 }}>Knowledge check</h2>
            <span style={{ fontFamily: d6.mono, fontSize: 12, fontWeight: 700, color: d6.dim }}>Q {QUIZ_QUESTION.n} OF {QUIZ_QUESTION.of} · PASS ≥ 80%</span>
          </div>
          {/* progress segments */}
          <div style={{ display: 'flex', gap: 4, marginBottom: 20 }}>
            {Array.from({ length: QUIZ_QUESTION.of }, (_, i) => (
              <span key={i} style={{ flex: 1, height: 5, borderRadius: 2, background: i < QUIZ_QUESTION.n - 1 ? d6.green : i === QUIZ_QUESTION.n - 1 ? d6.orange : '#EDF0EC' }}></span>
            ))}
          </div>
          <p style={{ margin: '0 0 18px', fontSize: 18, fontWeight: 700, lineHeight: 1.4 }}>{QUIZ_QUESTION.n}. {QUIZ_QUESTION.q}</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {QUIZ_QUESTION.options.map((o, i) => {
              const picked = i === QUIZ_QUESTION.picked;
              return (
                <label key={i} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 16px', borderRadius: 10, border: `2px solid ${picked ? d6.green : d6.border}`, background: picked ? d6.greenSoft : '#fff', fontSize: 15 }}>
                  <span style={{ width: 22, height: 22, borderRadius: 6, border: `2px solid ${picked ? d6.green : d6.dim}`, display: 'grid', placeItems: 'center', flexShrink: 0, background: '#fff' }}>
                    {picked && <span style={{ width: 11, height: 11, borderRadius: 3, background: d6.green }}></span>}
                  </span>
                  <span style={{ fontFamily: d6.mono, fontSize: 12, fontWeight: 700, color: picked ? d6.greenDark : d6.dim, width: 16 }}>{String.fromCharCode(65 + i)}.</span>
                  <span>{o}</span>
                </label>
              );
            })}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 22, paddingTop: 18, borderTop: `1px solid ${d6.border}` }}>
            <span style={{ background: d6.green, color: '#fff', fontWeight: 700, fontSize: 15, borderRadius: 8, padding: '11px 24px' }}>Record answer →</span>
            <span style={{ border: `1px solid ${d6.border}`, color: d6.muted, fontWeight: 700, fontSize: 15, borderRadius: 8, padding: '11px 22px' }}>Back</span>
            <span style={{ fontFamily: d6.mono, fontSize: 11, color: d6.dim, marginLeft: 'auto' }}>ATTEMPT 1 OF 3</span>
          </div>
        </D6Card>

        {/* Mentor sign-off */}
        <D6Card pad={0}>
          <div style={{ padding: '13px 16px', borderBottom: `1px solid ${d6.border}` }}><D6Label>Mentor sign-off</D6Label></div>
          <div style={{ padding: '14px 16px' }}>
            <p style={{ margin: '0 0 10px', fontFamily: d6.mono, fontSize: 10, letterSpacing: '0.06em', color: d6.muted }}>CHECKLIST — DEMONSTRATE TO MENTOR</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
              {CHECKLIST.map((c, i) => (
                <div key={i} style={{ display: 'flex', gap: 10, fontSize: 12.5, lineHeight: 1.45, color: d6.text }}>
                  <span style={{ width: 15, height: 15, borderRadius: 4, border: `2px solid ${d6.dim}`, flexShrink: 0, marginTop: 1 }}></span>{c}
                </div>
              ))}
            </div>
            <div style={{ marginTop: 16, paddingTop: 14, borderTop: `1px dashed ${d6.border}` }}>
              <p style={{ margin: '0 0 10px', fontFamily: d6.mono, fontSize: 10, color: d6.muted }}>MENTOR SIGNATURE — SCAN STUDENT PASSPORT</p>
              <div style={{ height: 46, borderBottom: `2px solid ${d6.text}`, display: 'flex', alignItems: 'flex-end', paddingBottom: 6 }}>
                <span style={{ fontSize: 11.5, fontWeight: 700, color: d6.orange, background: d6.orangeSoft, borderRadius: 999, padding: '3px 10px' }}>Awaiting demo</span>
              </div>
            </div>
          </div>
        </D6Card>
      </div>
    </D6Shell>
  );
}

// ---------------- Skill tree (Field Manual boxy · Clean LMS skin) ----------------
function d6NodeStyle(status) {
  switch (status) {
    case 'completed': return { fill: d6.greenSoft, stroke: d6.green, text: d6.greenDark, code: d6.green };
    case 'in_progress': return { fill: '#fff', stroke: d6.green, text: d6.text, code: d6.green };
    case 'available': return { fill: '#fff', stroke: '#B9C4BB', text: d6.text, code: d6.dim };
    case 'pending': return { fill: d6.orangeSoft, stroke: d6.orange, text: '#7A3D05', code: d6.orange };
    default: return { fill: '#F0F2EF', stroke: '#DDE3DD', text: d6.dim, code: '#C9D1CA' };
  }
}

const d6Code = { safety: 'GEN-001', handtool: 'MEC-010', cad: 'MEC-020', mill: 'MEC-101', bandsaw: 'MEC-102', cadadv: 'MEC-120', print3d: 'MEC-030', solder: 'ELE-010', wiring: 'ELE-101', lathe: 'MEC-103', cnc: 'MEC-201', pneu: 'MEC-110', drivetrain: 'MEC-301', electronics: 'ELE-201', inspect: 'GEN-900' };

function D6Tree() {
  const W = 1160, H = 600, mx = 88, my = 44;
  const px = (x) => mx + (x / 100) * (W - mx * 2);
  const py = (y) => my + (y / 100) * (H - my * 2);
  const byId = Object.fromEntries(TREE_NODES.map((n) => [n.id, n]));
  const nw = 150, nh = 46;
  const legend = [['Certified', d6.green, d6.greenSoft], ['In progress', d6.green, '#fff'], ['Ready', '#B9C4BB', '#fff'], ['Awaiting mentor', d6.orange, d6.orangeSoft], ['Locked', '#DDE3DD', '#F0F2EF']];
  return (
    <D6Shell active="tree">
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 14 }}>
        <div>
          <h1 style={{ margin: 0, fontSize: 22, fontWeight: 700 }}>Skill map</h1>
          <p style={{ margin: '3px 0 0', fontSize: 13, color: d6.muted }}>Courses unlock left to right as you complete prerequisites.</p>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          {['All teams', 'Mechanical', 'Electrical', 'Programming'].map((t, i) => (
            <span key={t} style={{ fontSize: 12.5, fontWeight: 700, padding: '6px 14px', borderRadius: 999, border: `1px solid ${i === 0 ? d6.green : d6.border}`, background: i === 0 ? d6.greenSoft : '#fff', color: i === 0 ? d6.greenDark : d6.muted }}>{t}</span>
          ))}
        </div>
      </div>
      <D6Card pad={0} style={{ position: 'relative' }}>
        <svg viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', height: 600, display: 'block' }}>
          {/* faint grid (field-manual paper) */}
          {Array.from({ length: Math.ceil(W / 40) }, (_, i) => <line key={'v' + i} x1={i * 40} y1="0" x2={i * 40} y2={H} stroke="#F1F3EF" strokeWidth="1" />)}
          {Array.from({ length: Math.ceil(H / 40) }, (_, i) => <line key={'h' + i} x1="0" y1={i * 40} x2={W} y2={i * 40} stroke="#F1F3EF" strokeWidth="1" />)}
          {/* orthogonal connectors (boxy) */}
          {TREE_EDGES.map(([a, b], i) => {
            const A = byId[a], B = byId[b];
            const x1 = px(A.x) + nw / 2, y1 = py(A.y), x2 = px(B.x) - nw / 2, y2 = py(B.y);
            const mid = x1 + (x2 - x1) * 0.5;
            const lit = A.status === 'completed';
            return (
              <g key={i}>
                <path d={`M ${x1} ${y1} H ${mid} V ${y2} H ${x2}`} fill="none" stroke={lit ? '#9DD4B0' : '#DDE3DD'} strokeWidth={lit ? 2 : 1.4} />
                <rect x={x2 - 2} y={y2 - 2} width={4} height={4} fill={lit ? d6.green : '#C9D1CA'} />
              </g>
            );
          })}
          {/* boxy square-cornered nodes */}
          {TREE_NODES.map((n) => {
            const s = d6NodeStyle(n.status);
            const x = px(n.x), y = py(n.y);
            const sel = n.status === 'in_progress';
            return (
              <g key={n.id}>
                {/* selection emphasis — drop shadow + outer ring */}
                {sel && <rect x={x - nw / 2 + 3} y={y - nh / 2 + 4} width={nw} height={nh} fill={d6.greenDark} opacity={0.18} />}
                {sel && <rect x={x - nw / 2 - 6} y={y - nh / 2 - 6} width={nw + 12} height={nh + 12} fill="none" stroke={d6.green} strokeWidth={1.5} strokeDasharray="3 3" />}
                <rect x={x - nw / 2} y={y - nh / 2} width={nw} height={nh} fill={sel ? '#fff' : s.fill} stroke={s.stroke} strokeWidth={sel ? 3 : 1.6} />
                {/* team accent bar (left edge) */}
                <rect x={x - nw / 2} y={y - nh / 2} width={5} height={nh} fill={d6TeamColor[n.team]} opacity={n.status === 'locked' ? 0.35 : 1} />
                <text x={x - nw / 2 + 15} y={y - 6} fontSize="8.5" fontFamily={d6.mono} fontWeight="700" letterSpacing="0.5" fill={s.code}>{d6Code[n.id]}</text>
                <text x={x - nw / 2 + 15} y={y + 11} fontSize="11" fontWeight="700" fill={s.text} fontFamily={d6.font}>{n.title.length > 20 ? n.title.slice(0, 19) + '…' : n.title}</text>
                {/* selected tab */}
                {sel && <rect x={x - nw / 2} y={y - nh / 2 - 19} width={92} height={16} fill={d6.green} />}
                {sel && <text x={x - nw / 2 + 8} y={y - nh / 2 - 7} fontSize="8.5" fontFamily={d6.mono} fontWeight="700" letterSpacing="0.5" fill="#fff">IN PROGRESS</text>}
              </g>
            );
          })}
        </svg>
        {/* legend */}
        <div style={{ position: 'absolute', left: 16, bottom: 14, display: 'flex', gap: 16, padding: '9px 14px', borderRadius: 10, background: '#fff', border: `1px solid ${d6.border}`, boxShadow: '0 2px 8px rgba(26,33,28,0.06)' }}>
          {legend.map(([l, stroke, fill]) => (
            <span key={l} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 11.5, color: d6.muted }}>
              <span style={{ width: 12, height: 12, background: fill, border: `2px solid ${stroke}` }}></span>{l}
            </span>
          ))}
        </div>
      </D6Card>
    </D6Shell>
  );
}

Object.assign(window, { D6Dashboard, D6Player, D6Tree });
