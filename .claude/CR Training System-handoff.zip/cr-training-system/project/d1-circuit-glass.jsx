// ============================================================
// D1 — CIRCUIT GLASS (safe · dark)
// The existing dark-glass portal, re-skinned to the modernized
// green brand. Familiar sidebar + glass cards, green aurora.
// ============================================================

const d1 = {
  bg: '#0B100D',
  surface: 'rgba(22, 30, 25, 0.62)',
  surfaceSolid: '#161E19',
  border: 'rgba(230, 244, 235, 0.09)',
  borderHover: 'rgba(230, 244, 235, 0.22)',
  text: '#E9F2EC',
  muted: '#9FB5A8',
  dim: '#69806F',
  accent: '#3DDC74',
  accentDeep: '#27B855',
  orange: '#E8842A',
  font: "'Archivo', sans-serif",
  display: "'Space Grotesk', sans-serif",
  mono: "'JetBrains Mono', monospace",
};

const d1TeamColor = { Mechanical: '#3DDC74', Electrical: '#E8842A', Programming: '#8FD6B8', General: '#9FB5A8' };

function D1Mesh() {
  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', width: 720, height: 520, left: '-8%', top: '-14%', background: 'radial-gradient(ellipse at center, rgba(39,184,85,0.16) 0%, transparent 65%)', filter: 'blur(8px)' }}></div>
      <div style={{ position: 'absolute', width: 640, height: 540, right: '-10%', bottom: '-18%', background: 'radial-gradient(ellipse at center, rgba(14,107,34,0.22) 0%, transparent 65%)', filter: 'blur(8px)' }}></div>
      <div style={{ position: 'absolute', width: 420, height: 320, right: '18%', top: '-10%', background: 'radial-gradient(ellipse at center, rgba(232,132,42,0.07) 0%, transparent 60%)', filter: 'blur(8px)' }}></div>
    </div>
  );
}

function D1Card({ children, style, pad = 16 }) {
  return (
    <div style={{ background: d1.surface, border: `1px solid ${d1.border}`, borderRadius: 16, padding: pad, backdropFilter: 'blur(14px)', boxShadow: '0 8px 32px -8px rgba(0,0,0,0.55), inset 0 1px 0 rgba(255,255,255,0.05)', position: 'relative', ...style }}>
      {children}
    </div>
  );
}

function D1Eyebrow({ children, style }) {
  return <p style={{ margin: 0, fontSize: 10, fontWeight: 700, letterSpacing: '0.18em', textTransform: 'uppercase', color: d1.muted, fontFamily: d1.font, ...style }}>{children}</p>;
}

function D1NavItem({ icon, label, active, badge }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px', borderRadius: 10, fontSize: 13.5, fontWeight: active ? 600 : 500, color: active ? d1.text : d1.muted, background: active ? 'rgba(61,220,116,0.12)' : 'transparent', border: active ? '1px solid rgba(61,220,116,0.25)' : '1px solid transparent' }}>
      <span style={{ color: active ? d1.accent : d1.dim, display: 'flex' }}>{icon}</span>
      <span style={{ flex: 1 }}>{label}</span>
      {badge && <span style={{ fontSize: 10.5, fontFamily: d1.mono, fontWeight: 700, background: 'rgba(232,132,42,0.18)', color: d1.orange, border: '1px solid rgba(232,132,42,0.35)', borderRadius: 999, padding: '1px 7px' }}>{badge}</span>}
    </div>
  );
}

function D1Shell({ children, active }) {
  const sec = { margin: '18px 0 6px', paddingLeft: 12 };
  return (
    <div className="ab" style={{ background: d1.bg, color: d1.text, fontFamily: d1.font, display: 'flex' }}>
      <D1Mesh />
      {/* Sidebar */}
      <aside style={{ width: 230, flexShrink: 0, borderRight: `1px solid ${d1.border}`, padding: '20px 14px 16px', display: 'flex', flexDirection: 'column', position: 'relative', background: 'rgba(11,16,13,0.6)', backdropFilter: 'blur(10px)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '0 8px 18px' }}>
          <img src="brand/torm.png" alt="" style={{ width: 30, height: 28, objectFit: 'contain' }} />
          <div>
            <div style={{ fontFamily: d1.display, fontWeight: 700, fontSize: 14, letterSpacing: '-0.01em' }}>CircuitRunners</div>
            <div style={{ fontSize: 10, color: d1.dim, letterSpacing: '0.08em', textTransform: 'uppercase' }}>Training portal</div>
          </div>
        </div>
        <D1NavItem icon={Icon.home(15)} label="Dashboard" active={active === 'dash'} />
        <D1NavItem icon={Icon.grid(15)} label="Coursework" active={active === 'player'} />
        <D1NavItem icon={Icon.tree(15)} label="Skill map" active={active === 'tree'} />
        <D1NavItem icon={Icon.scan(15)} label="Scan" />
        <D1Eyebrow style={sec}>Your subteams</D1Eyebrow>
        <D1NavItem icon={Icon.wrench(15)} label="CNC & Mill" />
        <D1NavItem icon={Icon.wrench(15)} label="Drivetrain" />
        <D1Eyebrow style={sec}>Mentor</D1Eyebrow>
        <D1NavItem icon={Icon.check(15)} label="Checkoffs" badge="3" />
        <D1NavItem icon={Icon.user(15)} label="Roster" />
        <div style={{ flex: 1 }}></div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: 10, borderRadius: 12, background: d1.surface, border: `1px solid ${d1.border}` }}>
          <div style={{ width: 32, height: 32, borderRadius: 999, background: 'linear-gradient(135deg, #27B855, #0E6B22)', display: 'grid', placeItems: 'center', fontWeight: 700, fontSize: 12, color: '#fff' }}>AS</div>
          <div style={{ minWidth: 0 }}>
            <div style={{ fontSize: 12.5, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>Aarush Sharma</div>
            <div style={{ fontSize: 10.5, color: d1.dim }}>Student · Lead</div>
          </div>
        </div>
      </aside>
      <main style={{ flex: 1, position: 'relative', padding: '26px 30px', overflow: 'hidden' }}>{children}</main>
    </div>
  );
}

function D1Chip({ color, children }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, borderRadius: 999, padding: '4px 12px', fontSize: 11.5, fontWeight: 600, background: `color-mix(in srgb, ${color} 16%, transparent)`, color: `color-mix(in srgb, ${color} 70%, white)`, border: `1px solid color-mix(in srgb, ${color} 35%, transparent)` }}>{children}</span>
  );
}

function D1Bar({ pct, color = d1.accent, h = 6 }) {
  return (
    <div style={{ height: h, borderRadius: 999, background: 'rgba(233,242,236,0.08)', overflow: 'hidden' }}>
      <div style={{ width: pct + '%', height: '100%', borderRadius: 999, background: color, boxShadow: `0 0 14px -2px ${color}` }}></div>
    </div>
  );
}

// ---------------- Dashboard ----------------
function D1Dashboard() {
  return (
    <D1Shell active="dash">
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 20, position: 'relative' }}>
        <div>
          <h1 style={{ margin: 0, fontFamily: d1.display, fontSize: 26, fontWeight: 700, letterSpacing: '-0.02em' }}>Hi <span style={{ color: d1.accent }}>Aarush</span></h1>
          <p style={{ margin: '2px 0 0', fontSize: 12, color: d1.muted }}>Wednesday · CircuitRunners Robotics</p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <D1Chip color={d1.accent}>● Checked in · 2h 14m</D1Chip>
          <D1Chip color={d1.orange}>3 checkoffs to review</D1Chip>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 252px', gap: 16, position: 'relative' }}>
        {/* Up next */}
        <D1Card>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
            <D1Eyebrow>Up next · 9</D1Eyebrow>
            <span style={{ fontSize: 12, color: d1.accent }}>See all →</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
            {COURSES.map((c, i) => (
              <div key={i} style={{ borderRadius: 12, border: `1px solid ${i === 0 ? 'rgba(61,220,116,0.35)' : d1.border}`, background: 'rgba(233,242,236,0.03)', padding: 12, minHeight: 86, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                <div style={{ fontSize: 13.5, fontWeight: 600, lineHeight: 1.3 }}>{c.title}</div>
                <div style={{ marginTop: 10 }}>
                  {c.status === 'in_progress' && <div style={{ marginBottom: 7 }}><D1Bar pct={(c.done / c.total) * 100} h={4} /></div>}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: 10, color: d1TeamColor[c.team], fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{c.team}</span>
                    <span style={{ fontSize: 10, color: d1.dim, fontFamily: d1.mono }}>{c.status === 'in_progress' ? `${c.done}/${c.total}` : 'ready'}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </D1Card>

        {/* Status rail */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <D1Card style={{ textAlign: 'center' }}>
            <D1Eyebrow>Student ID</D1Eyebrow>
            <div style={{ display: 'grid', placeItems: 'center', marginTop: 10 }}>
              <div style={{ background: '#fff', borderRadius: 10, padding: 8 }}><FakeQR size={104} /></div>
            </div>
          </D1Card>
          <D1Card>
            <D1Eyebrow>Hours · season</D1Eyebrow>
            <p style={{ margin: '6px 0 0', fontFamily: d1.mono, fontSize: 24, fontWeight: 700 }}>23.5</p>
            <p style={{ margin: '0 0 8px', fontSize: 11.5, color: d1.muted }}>of 40 target</p>
            <D1Bar pct={59} />
          </D1Card>
          <D1Card>
            <D1Eyebrow>Lettering progress</D1Eyebrow>
            <p style={{ margin: '6px 0 0', fontFamily: d1.mono, fontSize: 24, fontWeight: 700 }}>64% <span style={{ fontFamily: d1.font, fontSize: 11, fontWeight: 400, color: d1.dim }}>(2/5 reqs)</span></p>
            <div style={{ marginTop: 8 }}><D1Bar pct={64} color={d1.accentDeep} /></div>
          </D1Card>
        </div>
      </div>

      {/* Compact skill map */}
      <D1Card style={{ marginTop: 16 }} pad={0}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 16px 0' }}>
          <D1Eyebrow>Skill map · Mechanical path</D1Eyebrow>
          <span style={{ fontSize: 12, color: d1.accent }}>Open full map →</span>
        </div>
        <D1TreeSvg height={282} compact />
      </D1Card>
    </D1Shell>
  );
}

// ---------------- Skill tree SVG ----------------
function d1NodeFill(status) {
  switch (status) {
    case 'completed': return { fill: 'rgba(39,184,85,0.22)', stroke: '#27B855', text: d1.text, dot: '#3DDC74' };
    case 'in_progress': return { fill: 'rgba(61,220,116,0.10)', stroke: '#3DDC74', text: d1.text, dot: '#3DDC74' };
    case 'available': return { fill: 'rgba(233,242,236,0.05)', stroke: 'rgba(233,242,236,0.30)', text: d1.text, dot: '#9FB5A8' };
    case 'pending': return { fill: 'rgba(232,132,42,0.12)', stroke: '#E8842A', text: d1.text, dot: '#E8842A' };
    default: return { fill: 'rgba(233,242,236,0.02)', stroke: 'rgba(233,242,236,0.12)', text: d1.dim, dot: '#3A4A40' };
  }
}

function D1TreeSvg({ height = 600, compact = false, selected = null }) {
  const W = 1140, H = height;
  const mx = 80, my = compact ? 26 : 50;
  const px = (x) => mx + (x / 100) * (W - mx * 2);
  const py = (y) => my + (y / 100) * (H - my * 2);
  const byId = Object.fromEntries(TREE_NODES.map((n) => [n.id, n]));
  const nw = compact ? 118 : 150, nh = compact ? 30 : 40;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', height, display: 'block' }}>
      {TREE_EDGES.map(([a, b], i) => {
        const A = byId[a], B = byId[b];
        const x1 = px(A.x) + nw / 2, y1 = py(A.y), x2 = px(B.x) - nw / 2, y2 = py(B.y);
        const lit = A.status === 'completed';
        return <path key={i} d={`M ${x1} ${y1} C ${x1 + 50} ${y1}, ${x2 - 50} ${y2}, ${x2} ${y2}`} fill="none" stroke={lit ? 'rgba(61,220,116,0.45)' : 'rgba(233,242,236,0.10)'} strokeWidth={lit ? 1.8 : 1.2} />;
      })}
      {TREE_NODES.map((n) => {
        const s = d1NodeFill(n.status);
        const x = px(n.x), y = py(n.y);
        const isSel = selected === n.id;
        return (
          <g key={n.id}>
            <rect x={x - nw / 2} y={y - nh / 2} width={nw} height={nh} rx={compact ? 8 : 10} fill={s.fill} stroke={isSel ? '#3DDC74' : s.stroke} strokeWidth={isSel ? 2 : 1.2} />
            <circle cx={x - nw / 2 + 13} cy={y} r={3.2} fill={s.dot} />
            <text x={x - nw / 2 + 23} y={y + 3.5} fontSize={compact ? 9.5 : 11} fontWeight="600" fill={s.text} fontFamily={d1.font}>
              {compact && n.title.length > 20 ? n.title.slice(0, 19) + '…' : n.title.length > 24 ? n.title.slice(0, 23) + '…' : n.title}
            </text>
          </g>
        );
      })}
    </svg>
  );
}

function D1Tree() {
  const legend = [
    ['Completed', '#27B855'], ['In progress', '#3DDC74'], ['Ready', '#9FB5A8'], ['Awaiting mentor', '#E8842A'], ['Locked', '#3A4A40'],
  ];
  return (
    <D1Shell active="tree">
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 16, position: 'relative' }}>
        <div>
          <h1 style={{ margin: 0, fontFamily: d1.display, fontSize: 24, fontWeight: 700, letterSpacing: '-0.02em' }}>Skill map</h1>
          <p style={{ margin: '2px 0 0', fontSize: 12, color: d1.muted }}>Every course on your path · prerequisites flow left → right</p>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          {['All teams', 'Mechanical', 'Electrical', 'Programming'].map((t, i) => (
            <span key={t} style={{ fontSize: 11.5, fontWeight: 600, padding: '5px 12px', borderRadius: 999, border: `1px solid ${i === 0 ? 'rgba(61,220,116,0.4)' : d1.border}`, background: i === 0 ? 'rgba(61,220,116,0.12)' : 'transparent', color: i === 0 ? d1.accent : d1.muted }}>{t}</span>
          ))}
        </div>
      </div>
      <D1Card pad={0} style={{ position: 'relative' }}>
        <D1TreeSvg height={620} selected="bandsaw" />
        {/* Zoom controls */}
        <div style={{ position: 'absolute', right: 14, bottom: 14, display: 'flex', flexDirection: 'column', gap: 6 }}>
          {['+', '−', '⤢'].map((z) => (
            <div key={z} style={{ width: 30, height: 30, borderRadius: 8, background: d1.surfaceSolid, border: `1px solid ${d1.border}`, display: 'grid', placeItems: 'center', fontSize: 14, color: d1.muted }}>{z}</div>
          ))}
        </div>
        {/* Legend */}
        <div style={{ position: 'absolute', left: 14, bottom: 14, display: 'flex', gap: 14, padding: '8px 12px', borderRadius: 10, background: 'rgba(11,16,13,0.75)', border: `1px solid ${d1.border}`, backdropFilter: 'blur(8px)' }}>
          {legend.map(([l, c]) => (
            <span key={l} style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 10.5, color: d1.muted }}>
              <span style={{ width: 8, height: 8, borderRadius: 99, background: c }}></span>{l}
            </span>
          ))}
        </div>
        {/* Detail popover for selected node */}
        <div style={{ position: 'absolute', left: '36%', top: '16%', width: 250, borderRadius: 14, background: d1.surfaceSolid, border: '1px solid rgba(61,220,116,0.35)', boxShadow: '0 16px 48px -8px rgba(0,0,0,0.7)', padding: 14 }}>
          <D1Eyebrow style={{ color: d1TeamColor.Mechanical }}>Mechanical · Ready</D1Eyebrow>
          <div style={{ fontFamily: d1.display, fontSize: 15, fontWeight: 700, margin: '5px 0 4px' }}>Bandsaw Certification</div>
          <p style={{ margin: 0, fontSize: 11.5, color: d1.muted, lineHeight: 1.45 }}>3 blocks · video, quiz, mentor checkoff. Prereq <span style={{ color: d1.accent }}>Hand Tools ✓</span> complete.</p>
          <div style={{ marginTop: 10, display: 'inline-flex', alignItems: 'center', gap: 6, background: d1.accentDeep, color: '#06130A', fontWeight: 700, fontSize: 12, borderRadius: 9, padding: '7px 12px' }}>Start course {Icon.arrowR(13)}</div>
        </div>
      </D1Card>
    </D1Shell>
  );
}

// ---------------- Course player ----------------
function D1Player() {
  const stepIcon = { video: Icon.play(13), reading: Icon.book(13), quiz: Icon.quiz(13), checkoff: Icon.wrench(13) };
  return (
    <D1Shell active="player">
      <div style={{ position: 'relative' }}>
        <p style={{ margin: 0, fontSize: 11.5, color: d1.dim }}>Coursework <span style={{ margin: '0 4px' }}>/</span> <span style={{ color: d1.muted }}>Mill Safety & Operation</span></p>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '6px 0 16px' }}>
          <h1 style={{ margin: 0, fontFamily: d1.display, fontSize: 24, fontWeight: 700, letterSpacing: '-0.02em' }}>Mill Safety & Operation</h1>
          <D1Chip color={d1TeamColor.Mechanical}>Mechanical</D1Chip>
          <D1Chip color={d1.accent}>Quiz step</D1Chip>
        </div>

        {/* Step strip */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
          {PLAYER_BLOCKS.map((b, i) => {
            const cur = b.state === 'current', done = b.state === 'done';
            return (
              <div key={i} style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 9, padding: '10px 12px', borderRadius: 12, background: cur ? 'rgba(61,220,116,0.10)' : d1.surface, border: `1px solid ${cur ? 'rgba(61,220,116,0.4)' : d1.border}`, opacity: b.state === 'upcoming' ? 0.55 : 1 }}>
                <span style={{ width: 24, height: 24, borderRadius: 8, display: 'grid', placeItems: 'center', background: done ? 'rgba(39,184,85,0.25)' : 'rgba(233,242,236,0.07)', color: done ? d1.accent : cur ? d1.accent : d1.dim }}>
                  {done ? Icon.check(12) : stepIcon[b.type]}
                </span>
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontSize: 12, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', color: b.state === 'upcoming' ? d1.muted : d1.text }}>{i + 1}. {b.title}</div>
                  <div style={{ fontSize: 10, color: d1.dim }}>{b.meta}</div>
                </div>
              </div>
            );
          })}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: 16 }}>
          {/* Quiz block */}
          <D1Card pad={20}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
              <h2 style={{ margin: 0, fontFamily: d1.display, fontSize: 16, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ color: d1.accent }}>{Icon.quiz(15)}</span> Mill Safety Quiz
              </h2>
              <span style={{ fontFamily: d1.mono, fontSize: 11.5, color: d1.muted }}>Question {QUIZ_QUESTION.n} of {QUIZ_QUESTION.of}</span>
            </div>
            <div style={{ marginBottom: 14 }}><D1Bar pct={(QUIZ_QUESTION.n / QUIZ_QUESTION.of) * 100} h={4} /></div>
            <p style={{ margin: '0 0 14px', fontSize: 15.5, fontWeight: 600, lineHeight: 1.4 }}>{QUIZ_QUESTION.q}</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {QUIZ_QUESTION.options.map((o, i) => {
                const picked = i === QUIZ_QUESTION.picked;
                return (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 11, padding: '11px 14px', borderRadius: 11, border: `1px solid ${picked ? 'rgba(61,220,116,0.5)' : d1.border}`, background: picked ? 'rgba(61,220,116,0.10)' : 'rgba(233,242,236,0.025)' }}>
                    <span style={{ width: 16, height: 16, borderRadius: 99, border: `2px solid ${picked ? d1.accent : d1.dim}`, display: 'grid', placeItems: 'center' }}>
                      {picked && <span style={{ width: 7, height: 7, borderRadius: 99, background: d1.accent }}></span>}
                    </span>
                    <span style={{ fontSize: 13.5, color: picked ? d1.text : d1.muted }}>{o}</span>
                  </div>
                );
              })}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 18, paddingTop: 16, borderTop: `1px solid ${d1.border}` }}>
              <span style={{ background: d1.accentDeep, color: '#06130A', fontWeight: 700, fontSize: 13, borderRadius: 10, padding: '9px 18px' }}>Next question</span>
              <span style={{ fontSize: 11.5, color: d1.dim }}>80% required to pass · attempt 1 of 3</span>
            </div>
          </D1Card>

          {/* Right rail */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <D1Card>
              <D1Eyebrow>Module progress</D1Eyebrow>
              <p style={{ margin: '6px 0 8px', fontFamily: d1.mono, fontSize: 20, fontWeight: 700 }}>2<span style={{ color: d1.dim }}>/4</span> <span style={{ fontFamily: d1.font, fontSize: 11, fontWeight: 400, color: d1.dim }}>blocks done</span></p>
              <D1Bar pct={50} />
            </D1Card>
            <D1Card>
              <D1Eyebrow>Mentor checklist</D1Eyebrow>
              <ul style={{ margin: '10px 0 0', padding: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 8 }}>
                {CHECKLIST.slice(0, 4).map((c, i) => (
                  <li key={i} style={{ display: 'flex', gap: 8, fontSize: 12, color: d1.muted, lineHeight: 1.4 }}>
                    <span style={{ width: 5, height: 5, borderRadius: 99, background: d1.dim, marginTop: 6, flexShrink: 0 }}></span>{c}
                  </li>
                ))}
              </ul>
            </D1Card>
            <D1Card>
              <D1Eyebrow>Unlocks next</D1Eyebrow>
              <div style={{ marginTop: 8, display: 'flex', flexDirection: 'column', gap: 6 }}>
                {['Lathe Certification', 'CNC Router'].map((t) => (
                  <div key={t} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12.5, color: d1.muted }}>
                    <span style={{ color: d1.dim }}>{Icon.lock(12)}</span>{t}
                  </div>
                ))}
              </div>
            </D1Card>
          </div>
        </div>
      </div>
    </D1Shell>
  );
}

Object.assign(window, { D1Dashboard, D1Player, D1Tree });
