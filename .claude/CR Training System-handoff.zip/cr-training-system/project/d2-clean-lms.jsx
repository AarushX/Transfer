// ============================================================
// D2 — CLEAN LMS (safe · light)
// Conventional, calm, readable. Atkinson Hyperlegible, white
// surfaces, one green accent. Friendly to parents + rookies.
// ============================================================

const d2 = {
  bg: '#F4F6F3',
  card: '#FFFFFF',
  border: '#E2E7E0',
  text: '#1A211C',
  muted: '#5C6B60',
  dim: '#8B988E',
  green: '#1E9E4C',
  greenDark: '#0E6B22',
  greenSoft: '#E7F6EC',
  orange: '#C95F00',
  orangeSoft: '#FBEFE2',
  font: "'Atkinson Hyperlegible', sans-serif",
  mono: "'JetBrains Mono', monospace",
};

const d2TeamColor = { Mechanical: '#1E9E4C', Electrical: '#C95F00', Programming: '#3E7A8C', General: '#8B988E' };

function D2Card({ children, style, pad = 18 }) {
  return <div style={{ background: d2.card, border: `1px solid ${d2.border}`, borderRadius: 12, padding: pad, boxShadow: '0 1px 2px rgba(26,33,28,0.04)', ...style }}>{children}</div>;
}

function D2Label({ children, style }) {
  return <p style={{ margin: 0, fontSize: 11, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: d2.dim, ...style }}>{children}</p>;
}

function D2NavItem({ icon, label, active, badge }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px', borderRadius: 8, fontSize: 14, fontWeight: active ? 700 : 400, color: active ? d2.greenDark : d2.muted, background: active ? d2.greenSoft : 'transparent' }}>
      <span style={{ display: 'flex', color: active ? d2.green : d2.dim }}>{icon}</span>
      <span style={{ flex: 1 }}>{label}</span>
      {badge && <span style={{ fontSize: 11, fontWeight: 700, background: d2.orangeSoft, color: d2.orange, borderRadius: 999, padding: '1px 8px' }}>{badge}</span>}
    </div>
  );
}

function D2Shell({ children, active }) {
  return (
    <div className="ab" style={{ background: d2.bg, color: d2.text, fontFamily: d2.font, display: 'flex', flexDirection: 'column' }}>
      {/* Top bar */}
      <header style={{ height: 56, background: d2.card, borderBottom: `1px solid ${d2.border}`, display: 'flex', alignItems: 'center', gap: 16, padding: '0 20px', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, width: 212 }}>
          <img src="brand/torm.png" alt="" style={{ width: 26, height: 24, objectFit: 'contain' }} />
          <span style={{ fontWeight: 700, fontSize: 15 }}>CircuitRunners</span>
        </div>
        <div style={{ flex: 1, maxWidth: 420, display: 'flex', alignItems: 'center', gap: 8, background: d2.bg, border: `1px solid ${d2.border}`, borderRadius: 8, padding: '7px 12px', fontSize: 13, color: d2.dim }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="7" /><line x1="21" y1="21" x2="16.5" y2="16.5" /></svg>
          Search courses, people, machines…
        </div>
        <div style={{ flex: 1 }}></div>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 12.5, fontWeight: 700, color: d2.greenDark, background: d2.greenSoft, borderRadius: 999, padding: '5px 12px' }}>● Checked in · 2h 14m</span>
        <div style={{ width: 34, height: 34, borderRadius: 999, background: d2.greenDark, color: '#fff', display: 'grid', placeItems: 'center', fontWeight: 700, fontSize: 13 }}>AS</div>
      </header>
      <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
        {/* Sidebar */}
        <aside style={{ width: 212, flexShrink: 0, padding: '16px 12px', borderRight: `1px solid ${d2.border}`, background: d2.card, display: 'flex', flexDirection: 'column', gap: 2 }}>
          <D2NavItem icon={Icon.home(15)} label="Dashboard" active={active === 'dash'} />
          <D2NavItem icon={Icon.grid(15)} label="Coursework" active={active === 'player'} />
          <D2NavItem icon={Icon.tree(15)} label="Skill map" active={active === 'tree'} />
          <D2NavItem icon={Icon.scan(15)} label="Scan" />
          <D2NavItem icon={Icon.award(15)} label="Season" />
          <D2Label style={{ margin: '16px 0 6px', paddingLeft: 12 }}>Mentor</D2Label>
          <D2NavItem icon={Icon.check(15)} label="Checkoffs" badge="3" />
          <D2NavItem icon={Icon.wrench(15)} label="Machines" />
          <D2NavItem icon={Icon.user(15)} label="Roster" />
        </aside>
        <main style={{ flex: 1, padding: '24px 28px', minWidth: 0 }}>{children}</main>
      </div>
    </div>
  );
}

function D2Bar({ pct, color = d2.green, h = 6 }) {
  return (
    <div style={{ height: h, borderRadius: 999, background: '#EDF0EC', overflow: 'hidden' }}>
      <div style={{ width: pct + '%', height: '100%', borderRadius: 999, background: color }}></div>
    </div>
  );
}

function D2StatusChip({ status }) {
  const map = {
    in_progress: ['In progress', d2.greenSoft, d2.greenDark],
    ready: ['Ready to start', '#F0F2EF', d2.muted],
    pending: ['Awaiting mentor', d2.orangeSoft, d2.orange],
  };
  const [label, bg, color] = map[status] || map.ready;
  return <span style={{ fontSize: 11.5, fontWeight: 700, background: bg, color, borderRadius: 999, padding: '3px 10px', whiteSpace: 'nowrap' }}>{label}</span>;
}

// ---------------- Dashboard ----------------
function D2Dashboard() {
  const stats = [
    ['Modules certified', '12', null],
    ['In progress', '2', null],
    ['Hours this season', '23.5', 'of 40'],
    ['Lettering', '64%', '2 of 5 reqs'],
  ];
  return (
    <D2Shell active="dash">
      <h1 style={{ margin: 0, fontSize: 24, fontWeight: 700 }}>Welcome back, Aarush</h1>
      <p style={{ margin: '4px 0 18px', fontSize: 13.5, color: d2.muted }}>Wednesday, June 10 · Build season is 12 weeks out — keep your certifications moving.</p>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 16 }}>
        {stats.map(([l, v, s]) => (
          <D2Card key={l} pad={16}>
            <D2Label>{l}</D2Label>
            <p style={{ margin: '6px 0 0', fontSize: 26, fontWeight: 700 }}>{v} {s && <span style={{ fontSize: 12, fontWeight: 400, color: d2.dim }}>{s}</span>}</p>
          </D2Card>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: 16 }}>
        <D2Card pad={0}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 18px', borderBottom: `1px solid ${d2.border}` }}>
            <h2 style={{ margin: 0, fontSize: 15.5, fontWeight: 700 }}>Up next</h2>
            <span style={{ fontSize: 13, color: d2.green, fontWeight: 700 }}>View all coursework →</span>
          </div>
          {COURSES.slice(0, 7).map((c, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 18px', borderBottom: i < 6 ? `1px solid ${d2.border}` : 'none' }}>
              <span style={{ width: 8, height: 8, borderRadius: 99, background: d2TeamColor[c.team], flexShrink: 0 }}></span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 700 }}>{c.title}</div>
                <div style={{ fontSize: 12, color: d2.dim }}>{c.team} · {c.total} blocks</div>
              </div>
              {c.status === 'in_progress' && <div style={{ width: 120 }}><D2Bar pct={(c.done / c.total) * 100} h={5} /></div>}
              <D2StatusChip status={c.status} />
              <span style={{ color: d2.dim }}>{Icon.arrowR(14)}</span>
            </div>
          ))}
        </D2Card>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <D2Card style={{ textAlign: 'center' }}>
            <D2Label>Student ID</D2Label>
            <div style={{ display: 'grid', placeItems: 'center', margin: '10px 0 6px' }}>
              <div style={{ border: `1px solid ${d2.border}`, borderRadius: 10, padding: 8 }}><FakeQR size={108} /></div>
            </div>
            <p style={{ margin: 0, fontSize: 11.5, color: d2.dim }}>Show to a mentor for checkoffs,<br />machines & attendance</p>
          </D2Card>
          <D2Card>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <D2Label>Lettering progress</D2Label>
              <span style={{ fontFamily: d2.mono, fontSize: 13, fontWeight: 700, color: d2.greenDark }}>64%</span>
            </div>
            <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 9 }}>
              {[['Outreach hours', 80, true], ['Shop hours', 59, false], ['Competition', 100, true], ['Parent volunteer', 20, false]].map(([l, p, met]) => (
                <div key={l}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 3 }}>
                    <span style={{ color: d2.muted }}>{l}</span>
                    <span style={{ color: met ? d2.green : d2.dim, fontWeight: 700 }}>{met ? '✓' : p + '%'}</span>
                  </div>
                  <D2Bar pct={p} h={4} color={met ? d2.green : '#9DBBA6'} />
                </div>
              ))}
            </div>
          </D2Card>
        </div>
      </div>
    </D2Shell>
  );
}

// ---------------- Course player ----------------
function D2Player() {
  const stepIcon = { video: Icon.play(13), reading: Icon.book(13), quiz: Icon.quiz(13), checkoff: Icon.wrench(13) };
  return (
    <D2Shell active="player">
      <p style={{ margin: 0, fontSize: 12.5, color: d2.dim }}>Coursework / <strong style={{ color: d2.muted }}>Mill Safety & Operation</strong></p>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, margin: '6px 0 16px' }}>
        <h1 style={{ margin: 0, fontSize: 22, fontWeight: 700 }}>Mill Safety & Operation</h1>
        <span style={{ fontSize: 11.5, fontWeight: 700, color: d2TeamColor.Mechanical, background: d2.greenSoft, borderRadius: 999, padding: '3px 10px' }}>Mechanical</span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr', gap: 16, alignItems: 'start' }}>
        {/* Syllabus rail */}
        <D2Card pad={0}>
          <div style={{ padding: '14px 16px', borderBottom: `1px solid ${d2.border}` }}>
            <D2Label>Module steps</D2Label>
            <div style={{ marginTop: 8 }}><D2Bar pct={50} /></div>
            <p style={{ margin: '6px 0 0', fontSize: 12, color: d2.dim }}>2 of 4 complete</p>
          </div>
          {PLAYER_BLOCKS.map((b, i) => {
            const cur = b.state === 'current', done = b.state === 'done';
            return (
              <div key={i} style={{ display: 'flex', gap: 11, padding: '12px 16px', background: cur ? d2.greenSoft : 'transparent', borderLeft: `3px solid ${cur ? d2.green : 'transparent'}`, borderBottom: i < 3 ? `1px solid ${d2.border}` : 'none', opacity: b.state === 'upcoming' ? 0.6 : 1 }}>
                <span style={{ width: 26, height: 26, borderRadius: 99, flexShrink: 0, display: 'grid', placeItems: 'center', background: done ? d2.green : '#EDF0EC', color: done ? '#fff' : cur ? d2.greenDark : d2.dim }}>
                  {done ? Icon.check(12) : stepIcon[b.type]}
                </span>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: cur ? d2.greenDark : d2.text }}>{b.title}</div>
                  <div style={{ fontSize: 11.5, color: d2.dim }}>{b.meta}</div>
                </div>
              </div>
            );
          })}
        </D2Card>

        {/* Active quiz */}
        <D2Card pad={24}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
            <h2 style={{ margin: 0, fontSize: 17, fontWeight: 700 }}>Mill Safety Quiz</h2>
            <span style={{ fontFamily: d2.mono, fontSize: 12, color: d2.dim }}>Question {QUIZ_QUESTION.n} of {QUIZ_QUESTION.of}</span>
          </div>
          <p style={{ margin: '0 0 16px', fontSize: 12.5, color: d2.dim }}>80% required to pass · attempt 1 of 3</p>
          <p style={{ margin: '0 0 16px', fontSize: 16.5, fontWeight: 700, lineHeight: 1.45 }}>{QUIZ_QUESTION.q}</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {QUIZ_QUESTION.options.map((o, i) => {
              const picked = i === QUIZ_QUESTION.picked;
              return (
                <label key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '13px 16px', borderRadius: 10, border: `2px solid ${picked ? d2.green : d2.border}`, background: picked ? d2.greenSoft : '#fff', fontSize: 14.5 }}>
                  <span style={{ width: 18, height: 18, borderRadius: 99, border: `2px solid ${picked ? d2.green : d2.dim}`, display: 'grid', placeItems: 'center', flexShrink: 0 }}>
                    {picked && <span style={{ width: 8, height: 8, borderRadius: 99, background: d2.green }}></span>}
                  </span>
                  {o}
                </label>
              );
            })}
          </div>
          <div style={{ display: 'flex', gap: 10, marginTop: 20, paddingTop: 18, borderTop: `1px solid ${d2.border}` }}>
            <span style={{ background: d2.green, color: '#fff', fontWeight: 700, fontSize: 14, borderRadius: 8, padding: '10px 20px' }}>Next question</span>
            <span style={{ border: `1px solid ${d2.border}`, color: d2.muted, fontWeight: 700, fontSize: 14, borderRadius: 8, padding: '10px 20px' }}>Back</span>
          </div>
        </D2Card>
      </div>
    </D2Shell>
  );
}

// ---------------- Skill tree ----------------
function d2NodeStyle(status) {
  switch (status) {
    case 'completed': return { fill: '#E7F6EC', stroke: d2.green, text: d2.greenDark, dot: d2.green };
    case 'in_progress': return { fill: '#fff', stroke: d2.green, text: d2.text, dot: d2.green };
    case 'available': return { fill: '#fff', stroke: '#B9C4BB', text: d2.text, dot: '#8B988E' };
    case 'pending': return { fill: d2.orangeSoft, stroke: d2.orange, text: '#7A3D05', dot: d2.orange };
    default: return { fill: '#F0F2EF', stroke: '#E2E7E0', text: d2.dim, dot: '#C9D1CA' };
  }
}

function D2Tree() {
  const W = 1140, H = 640, mx = 84, my = 46;
  const px = (x) => mx + (x / 100) * (W - mx * 2);
  const py = (y) => my + (y / 100) * (H - my * 2);
  const byId = Object.fromEntries(TREE_NODES.map((n) => [n.id, n]));
  const nw = 152, nh = 42;
  const legend = [['Completed', d2.green, '#E7F6EC'], ['In progress', d2.green, '#fff'], ['Ready', '#8B988E', '#fff'], ['Awaiting mentor', d2.orange, d2.orangeSoft], ['Locked', '#C9D1CA', '#F0F2EF']];
  return (
    <D2Shell active="tree">
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 14 }}>
        <div>
          <h1 style={{ margin: 0, fontSize: 22, fontWeight: 700 }}>Skill map</h1>
          <p style={{ margin: '3px 0 0', fontSize: 13, color: d2.muted }}>Courses unlock left to right as you complete prerequisites.</p>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          {['All teams', 'Mechanical', 'Electrical', 'Programming'].map((t, i) => (
            <span key={t} style={{ fontSize: 12.5, fontWeight: 700, padding: '6px 14px', borderRadius: 999, border: `1px solid ${i === 0 ? d2.green : d2.border}`, background: i === 0 ? d2.greenSoft : '#fff', color: i === 0 ? d2.greenDark : d2.muted }}>{t}</span>
          ))}
        </div>
      </div>
      <D2Card pad={0} style={{ position: 'relative' }}>
        <svg viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', height: 640, display: 'block' }}>
          {TREE_EDGES.map(([a, b], i) => {
            const A = byId[a], B = byId[b];
            const x1 = px(A.x) + nw / 2, y1 = py(A.y), x2 = px(B.x) - nw / 2, y2 = py(B.y);
            const lit = A.status === 'completed';
            return <path key={i} d={`M ${x1} ${y1} C ${x1 + 50} ${y1}, ${x2 - 50} ${y2}, ${x2} ${y2}`} fill="none" stroke={lit ? '#9DD4B0' : '#DDE3DD'} strokeWidth={lit ? 2 : 1.4} />;
          })}
          {TREE_NODES.map((n) => {
            const s = d2NodeStyle(n.status);
            const x = px(n.x), y = py(n.y);
            return (
              <g key={n.id}>
                <rect x={x - nw / 2} y={y - nh / 2} width={nw} height={nh} rx={9} fill={s.fill} stroke={s.stroke} strokeWidth={1.6} />
                <circle cx={x - nw / 2 + 14} cy={y} r={3.5} fill={s.dot} />
                <text x={x - nw / 2 + 25} y={y + 4} fontSize="11.5" fontWeight="700" fill={s.text} fontFamily={d2.font}>{n.title.length > 22 ? n.title.slice(0, 21) + '…' : n.title}</text>
              </g>
            );
          })}
        </svg>
        <div style={{ position: 'absolute', left: 16, bottom: 14, display: 'flex', gap: 16, padding: '9px 14px', borderRadius: 10, background: '#fff', border: `1px solid ${d2.border}`, boxShadow: '0 2px 8px rgba(26,33,28,0.06)' }}>
          {legend.map(([l, stroke, fill]) => (
            <span key={l} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 11.5, color: d2.muted }}>
              <span style={{ width: 12, height: 12, borderRadius: 4, background: fill, border: `2px solid ${stroke}` }}></span>{l}
            </span>
          ))}
        </div>
        <div style={{ position: 'absolute', right: 14, bottom: 14, display: 'flex', gap: 6 }}>
          {['−', '+', 'Fit'].map((z) => (
            <div key={z} style={{ minWidth: 32, height: 32, borderRadius: 8, background: '#fff', border: `1px solid ${d2.border}`, display: 'grid', placeItems: 'center', fontSize: 13, fontWeight: 700, color: d2.muted, padding: '0 8px' }}>{z}</div>
          ))}
        </div>
      </D2Card>
    </D2Shell>
  );
}

Object.assign(window, { D2Dashboard, D2Player, D2Tree });
