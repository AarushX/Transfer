// App shell — composes the canvas. Direction components are looked up on
// window so missing/in-progress directions render a placeholder frame.
const { DesignCanvas, DCSection, DCArtboard, DCPostIt } = window;

function Placeholder({ name }) {
  return (
    <div className="ab" style={{ display: 'grid', placeItems: 'center', background: 'repeating-linear-gradient(45deg, #F3F3EF 0 14px, #ECECE6 14px 28px)', color: '#777', fontFamily: "'JetBrains Mono', monospace", fontSize: 14 }}>
      {name} — in progress
    </div>
  );
}

const get = (n) => window[n] || (() => <Placeholder name={n} />);

function App() {
  const D = {
    d1d: get('D1Dashboard'), d1p: get('D1Player'), d1t: get('D1Tree'),
    d2d: get('D2Dashboard'), d2p: get('D2Player'), d2t: get('D2Tree'),
    d3d: get('D3Dashboard'), d3p: get('D3Player'), d3t: get('D3Tree'),
    d4d: get('D4Dashboard'), d4p: get('D4Player'), d4t: get('D4Tree'),
    d5d: get('D5Dashboard'), d5p: get('D5Player'), d5t: get('D5Tree'),
  };
  const W = 1440;
  return (
    <DesignCanvas title="CircuitRunners — UI Explorations">
      <DCSection id="intro" title="Context & assumptions" subtitle="Read me first">
        <DCArtboard id="notes" label="Designer notes" width={760} height={580}>
          <window.IntroNotes />
        </DCArtboard>
      </DCSection>

      <DCSection id="d1" title="1 · Circuit Glass — SAFE · dark" subtitle="The current dark-glass UI re-skinned to the modernized green brand. Familiar sidebar layout, glass cards, green aurora.">
        <DCArtboard id="d1-dash" label="Dashboard" width={W} height={1020}><D.d1d /></DCArtboard>
        <DCArtboard id="d1-player" label="Course player" width={W} height={940}><D.d1p /></DCArtboard>
        <DCArtboard id="d1-tree" label="Skill tree" width={W} height={880}><D.d1t /></DCArtboard>
      </DCSection>

      <DCSection id="d2" title="2 · Clean LMS — SAFE · light" subtitle="Conventional, calm, readable. Atkinson Hyperlegible, white surfaces, green as the single accent. Built for parents + new members too.">
        <DCArtboard id="d2-dash" label="Dashboard" width={W} height={1020}><D.d2d /></DCArtboard>
        <DCArtboard id="d2-player" label="Course player" width={W} height={940}><D.d2p /></DCArtboard>
        <DCArtboard id="d2-tree" label="Skill tree" width={W} height={880}><D.d2t /></DCArtboard>
      </DCSection>

      <DCSection id="d3" title="3 · Pit Wall — EXPERIMENTAL · dark" subtitle="Command-deck density. Top status bar instead of a sidebar, telemetry-style data, mono type. The portal as a race-ops console.">
        <DCArtboard id="d3-dash" label="Dashboard" width={W} height={1020}><D.d3d /></DCArtboard>
        <DCArtboard id="d3-player" label="Course player" width={W} height={940}><D.d3p /></DCArtboard>
        <DCArtboard id="d3-tree" label="Skill tree" width={W} height={880}><D.d3t /></DCArtboard>
      </DCSection>

      <DCSection id="d4" title="4 · Field Manual — EXPERIMENTAL · light" subtitle="Shop-floor print aesthetic: paper, rules, placard caps, work-order layouts. Courses read like numbered procedures.">
        <DCArtboard id="d4-dash" label="Dashboard" width={W} height={1020}><D.d4d /></DCArtboard>
        <DCArtboard id="d4-player" label="Course player · work order" width={W} height={940}><D.d4p /></DCArtboard>
        <DCArtboard id="d4-tree" label="Skill tree · route map" width={W} height={880}><D.d4t /></DCArtboard>
      </DCSection>

      <DCSection id="d5" title="5 · Kinetic — EXPERIMENTAL · dark" subtitle="“From potential to kinetic.” Big type, diagonal energy, circuit-trace motifs, oversized progress. The most brand-forward take.">
        <DCArtboard id="d5-dash" label="Dashboard" width={W} height={1020}><D.d5d /></DCArtboard>
        <DCArtboard id="d5-player" label="Course player" width={W} height={940}><D.d5p /></DCArtboard>
        <DCArtboard id="d5-tree" label="Skill tree · trace map" width={W} height={880}><D.d5t /></DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

function IntroNotes() {
  const li = { margin: '0 0 10px' };
  return (
    <div className="ab" style={{ background: '#FFFDF5', padding: '36px 40px', fontFamily: "'Atkinson Hyperlegible', sans-serif", color: '#222', lineHeight: 1.5 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
        <img src="brand/torm.png" alt="TORM" style={{ width: 40, height: 38, objectFit: 'contain' }} />
        <div>
          <div style={{ fontFamily: "'Archivo', sans-serif", fontWeight: 800, fontSize: 18, letterSpacing: '-0.01em' }}>CircuitRunners training portal — UI explorations</div>
          <div style={{ fontSize: 13, color: '#666' }}>5 directions × 3 key pages · desktop 1440 · June 2026</div>
        </div>
      </div>
      <div style={{ fontSize: 14 }}>
        <p style={{ margin: '0 0 10px' }}><strong>What I read:</strong> the Transfer repo (SvelteKit + Supabase LMS — dashboard, course player with video/reading/quiz/checkoff blocks, prerequisite skill tree) and the 2023–24 brand standards.</p>
        <p style={{ margin: '0 0 10px' }}><strong>Brand, modernized per your note:</strong> kept the green family but retuned it — primary <span style={{ background: '#27B855', color: '#fff', padding: '0 6px', borderRadius: 3 }}>#27B855</span> / deep <span style={{ background: '#0E6B22', color: '#fff', padding: '0 6px', borderRadius: 3 }}>#0E6B22</span>, alloy orange <span style={{ background: '#C95F00', color: '#fff', padding: '0 6px', borderRadius: 3 }}>#C95F00</span> kept as a warning/secondary accent, and neutrals shifted from pure black/grey to green-tinted ink + warm paper.</p>
        <p style={{ margin: '0 0 6px' }}><strong>Assumptions:</strong></p>
        <ul style={{ margin: '0 0 10px', paddingLeft: 20 }}>
          <li style={li}>Same data on every direction (one student, same 9 courses, same tree) so you compare style, not content.</li>
          <li style={li}>You said restructure freely — directions 3–5 rethink nav and hierarchy, not just paint.</li>
          <li style={li}>Type varies by direction: Space Grotesk/Archivo · Atkinson Hyperlegible · JetBrains Mono · Saira Condensed · Archivo Black.</li>
          <li style={li}>QR codes are placeholders; photos/video stills are striped placeholder slots.</li>
        </ul>
        <p style={{ margin: 0 }}><strong>How to review:</strong> scroll/zoom the canvas, double-click an artboard to focus it. Directions are mix-and-matchable — e.g. Pit Wall's status bar on Clean LMS surfaces. Tell me which atoms you like and I'll combine.</p>
      </div>
    </div>
  );
}

Object.assign(window, { IntroNotes });
ReactDOM.createRoot(document.getElementById('root')).render(<App />);
