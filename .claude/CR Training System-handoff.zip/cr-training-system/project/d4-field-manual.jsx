// ============================================================
// D4 — FIELD MANUAL (experimental · light)
// Shop-floor print aesthetic: paper, hard rules, placard caps,
// stamps, work-order layouts. Courses read like procedures.
// ============================================================

const d4 = {
  paper: '#FAF8F2',
  card: '#FFFFFF',
  ink: '#16190F',
  muted: '#55604F',
  dim: '#8C947F',
  rule: '#16190F',
  ruleSoft: '#D9D9CC',
  green: '#1C8F43',
  greenDeep: '#0E6B22',
  orange: '#C95F00',
  cond: "'Saira Condensed', sans-serif",
  body: "'Atkinson Hyperlegible', sans-serif",
  mono: "'JetBrains Mono', monospace",
};

function D4Hazard({ h = 8, color = d4.orange }) {
  return <div style={{ height: h, background: `repeating-linear-gradient(-45deg, ${d4.ink} 0 12px, ${color} 12px 24px)` }}></div>;
}

function D4Stamp({ children, color = d4.green, rotate = -4, style }) {
  return (
    <span style={{ display: 'inline-block', transform: `rotate(${rotate}deg)`, border: `2.5px solid ${color}`, color, fontFamily: d4.cond, fontWeight: 700, fontSize: 15, letterSpacing: '0.14em', textTransform: 'uppercase', padding: '3px 12px', borderRadius: 4, opacity: 0.9, ...style }}>{children}</span>
  );
}

function D4SecHead({ no, title, right }) {
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, borderBottom: `2.5px solid ${d4.rule}`, paddingBottom: 6, marginBottom: 0 }}>
      <span style={{ fontFamily: d4.mono, fontSize: 12, fontWeight: 700, color: d4.dim }}>§{no}</span>
      <span style={{ fontFamily: d4.cond, fontWeight: 700, fontSize: 21, letterSpacing: '0.1em', textTransform: 'uppercase', color: d4.ink }}>{title}</span>
      <span style={{ flex: 1 }}></span>
      {right}
    </div>
  );
}

function D4Shell({ children, active, docCode }) {
  const nav = [['dash', '01', 'Dashboard'], ['player', '02', 'Coursework'], ['tree', '03', 'Skill map'], [null, '04', 'Scan'], [null, '05', 'Season'], [null, '06', 'Mentor']];
  return (
    <div className="ab" style={{ background: d4.paper, color: d4.ink, fontFamily: d4.body, display: 'flex', flexDirection: 'column' }}>
      {/* Masthead */}
      <header style={{ background: d4.ink, color: '#F4F2E8', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 26px' }}>
          <img src="brand/torm.png" alt="" style={{ width: 30, height: 28, objectFit: 'contain' }} />
          <span style={{ fontFamily: d4.cond, fontWeight: 700, fontSize: 22, letterSpacing: '0.22em', textTransform: 'uppercase' }}>CircuitRunners · Training Record</span>
          <span style={{ flex: 1 }}></span>
          <span style={{ fontFamily: d4.mono, fontSize: 11, color: '#B9C2A9' }}>{docCode}</span>
          <span style={{ fontFamily: d4.mono, fontSize: 11, color: '#B9C2A9' }}>REV 2026.06</span>
          <span style={{ fontFamily: d4.mono, fontSize: 11, background: d4.green, color: '#fff', padding: '3px 10px', borderRadius: 2, fontWeight: 700 }}>SHARMA, A. · CR-0427</span>
        </div>
        <D4Hazard />
      </header>
      <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
        {/* Margin index rail */}
        <aside style={{ width: 170, flexShrink: 0, borderRight: `2.5px solid ${d4.rule}`, padding: '22px 0', display: 'flex', flexDirection: 'column' }}>
          {nav.map(([key, no, label]) => {
            const a = key === active;
            return (
              <div key={no} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 18px', background: a ? d4.ink : 'transparent', color: a ? '#F4F2E8' : d4.muted, borderBottom: `1px solid ${d4.ruleSoft}` }}>
                <span style={{ fontFamily: d4.mono, fontSize: 11, fontWeight: 700, color: a ? '#9FE2B5' : d4.dim }}>{no}</span>
                <span style={{ fontFamily: d4.cond, fontWeight: 600, fontSize: 16, letterSpacing: '0.08em', textTransform: 'uppercase' }}>{label}</span>
              </div>
            );
          })}
          <div style={{ flex: 1 }}></div>
          <div style={{ padding: '0 18px' }}>
            <div style={{ border: `2px solid ${d4.rule}`, padding: 9, background: '#fff' }}>
              <div style={{ fontFamily: d4.mono, fontSize: 9, letterSpacing: '0.1em', color: d4.muted, marginBottom: 6 }}>STUDENT PASSPORT</div>
              <FakeQR size={108} dark={d4.ink} />
            </div>
            <div style={{ fontFamily: d4.mono, fontSize: 9, color: d4.dim, marginTop: 6, lineHeight: 1.6 }}>PRESENT TO MENTOR FOR CHECKOFF / MACHINE AUTH</div>
          </div>
        </aside>
        <main style={{ flex: 1, padding: '24px 30px', minWidth: 0, position: 'relative' }}>{children}</main>
      </div>
    </div>
  );
}

const d4StatusStamp = {
  in_progress: ['IN WORK', d4.orange],
  ready: ['CLEARED TO START', d4.green],
  pending: ['HOLD — MENTOR', d4.orange],
  completed: ['CERTIFIED', d4.greenDeep],
  locked: ['LOCKED', '#9AA08E'],
  available: ['CLEARED', d4.green],
};

// ---------------- Dashboard ----------------
function D4Dashboard() {
  return (
    <D4Shell active="dash" docCode="DOC CR-DB-01">
      {/* Status strip */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 18, marginBottom: 20 }}>
        <div>
          <div style={{ fontFamily: d4.cond, fontWeight: 700, fontSize: 34, letterSpacing: '0.04em', textTransform: 'uppercase', lineHeight: 1 }}>Daily worksheet</div>
          <div style={{ fontFamily: d4.mono, fontSize: 11.5, color: d4.muted, marginTop: 4 }}>WED 10 JUN 2026 · SHOP OPEN · SESSION 02:14</div>
        </div>
        <span style={{ flex: 1 }}></span>
        <D4Stamp color={d4.green}>Checked in</D4Stamp>
        <D4Stamp color={d4.orange} rotate={3}>3 checkoffs waiting</D4Stamp>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: 26 }}>
        <div>
          <D4SecHead no="1.0" title="Up next — work queue" right={<span style={{ fontFamily: d4.mono, fontSize: 10.5, color: d4.dim }}>9 ITEMS · PRIORITY ORDER</span>} />
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13.5 }}>
            <thead>
              <tr>
                {['NO.', 'MODULE', 'SUBTEAM', 'BLOCKS', 'STATUS'].map((h) => (
                  <th key={h} style={{ textAlign: 'left', fontFamily: d4.mono, fontSize: 9.5, letterSpacing: '0.12em', color: d4.dim, fontWeight: 600, padding: '8px 8px 5px', borderBottom: `1.5px solid ${d4.rule}` }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {COURSES.map((c, i) => {
                const [label, color] = d4StatusStamp[c.status];
                return (
                  <tr key={i} style={{ background: i === 0 ? '#F1EFE2' : 'transparent' }}>
                    <td style={{ fontFamily: d4.mono, fontSize: 11, color: d4.dim, padding: '9px 8px', borderBottom: `1px solid ${d4.ruleSoft}`, width: 36 }}>{String(i + 1).padStart(2, '0')}</td>
                    <td style={{ fontWeight: 700, padding: '9px 8px', borderBottom: `1px solid ${d4.ruleSoft}` }}>{c.title}</td>
                    <td style={{ padding: '9px 8px', borderBottom: `1px solid ${d4.ruleSoft}`, fontFamily: d4.mono, fontSize: 11, color: d4.muted }}>{c.team.toUpperCase()}</td>
                    <td style={{ padding: '9px 8px', borderBottom: `1px solid ${d4.ruleSoft}` }}>
                      <span style={{ display: 'inline-flex', gap: 3 }}>
                        {Array.from({ length: c.total }, (_, j) => (
                          <span key={j} style={{ width: 11, height: 11, border: `1.5px solid ${d4.ink}`, background: j < c.done ? d4.green : 'transparent', display: 'inline-block' }}></span>
                        ))}
                      </span>
                    </td>
                    <td style={{ padding: '9px 8px', borderBottom: `1px solid ${d4.ruleSoft}` }}>
                      <span style={{ fontFamily: d4.cond, fontWeight: 700, fontSize: 13, letterSpacing: '0.1em', color }}>{label}</span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          <div style={{ marginTop: 26 }}>
            <D4SecHead no="2.0" title="Skill route — mechanical" right={<span style={{ fontFamily: d4.mono, fontSize: 10.5, color: d4.dim }}>SEE §03 FOR FULL MAP</span>} />
            <D4RouteStrip />
          </div>
        </div>

        {/* Right column: season record */}
        <div>
          <D4SecHead no="3.0" title="Season record" />
          <div style={{ border: `2px solid ${d4.rule}`, borderTop: 'none', background: '#fff' }}>
            {[['SHOP HOURS', '23.5 / 40', 59, false], ['OUTREACH HRS', '12 / 15', 80, false], ['COMPETITION', '2 / 2', 100, true], ['PARENT VOL.', '1 / 5', 20, false]].map(([l, v, p, met], i) => (
              <div key={l} style={{ padding: '12px 14px', borderBottom: i < 3 ? `1px solid ${d4.ruleSoft}` : 'none' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                  <span style={{ fontFamily: d4.mono, fontSize: 10, letterSpacing: '0.1em', color: d4.muted }}>{l}</span>
                  <span style={{ fontFamily: d4.mono, fontSize: 13, fontWeight: 700, color: met ? d4.greenDeep : d4.ink }}>{v}</span>
                </div>
                <div style={{ marginTop: 7, height: 10, border: `1.5px solid ${d4.ink}`, position: 'relative' }}>
                  <div style={{ position: 'absolute', inset: 1, width: `calc(${p}% - 2px)`, background: met ? d4.greenDeep : d4.green }}></div>
                </div>
              </div>
            ))}
            <div style={{ padding: '12px 14px', background: '#F1EFE2', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontFamily: d4.cond, fontWeight: 700, fontSize: 16, letterSpacing: '0.1em' }}>LETTERING</span>
              <span style={{ fontFamily: d4.mono, fontWeight: 700, fontSize: 15 }}>64% · 2/5 REQS</span>
            </div>
          </div>

          <div style={{ marginTop: 22 }}>
            <D4SecHead no="4.0" title="Certifications" />
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, paddingTop: 12 }}>
              {['MILL — PENDING', 'HAND TOOLS ✓', 'SHOP SAFETY ✓', '3D PRINT ✓', 'BANDSAW —'].map((c) => {
                const done = c.includes('✓');
                return <span key={c} style={{ fontFamily: d4.mono, fontSize: 10.5, fontWeight: 700, border: `1.5px solid ${done ? d4.greenDeep : d4.ruleSoft}`, color: done ? d4.greenDeep : d4.dim, padding: '4px 9px', background: done ? '#EAF5EC' : '#fff' }}>{c}</span>;
              })}
            </div>
          </div>
        </div>
      </div>
    </D4Shell>
  );
}

// Mini horizontal route strip for the dashboard
function D4RouteStrip() {
  const steps = [
    ['Shop Safety', 'completed'], ['Hand Tools', 'completed'], ['Mill Safety', 'in_progress'], ['Lathe', 'locked'], ['Drivetrain', 'locked'], ['Inspection', 'locked'],
  ];
  return (
    <div style={{ display: 'flex', alignItems: 'center', padding: '26px 6px 10px' }}>
      {steps.map(([t, s], i) => (
        <React.Fragment key={t}>
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 7, width: 92 }}>
            <span style={{ width: 22, height: 22, borderRadius: 99, border: `2.5px solid ${s === 'locked' ? d4.dim : d4.ink}`, background: s === 'completed' ? d4.green : s === 'in_progress' ? d4.orange : '#fff', display: 'grid', placeItems: 'center', color: '#fff' }}>
              {s === 'completed' && Icon.check(11)}
            </span>
            <span style={{ fontFamily: d4.mono, fontSize: 9.5, color: s === 'locked' ? d4.dim : d4.ink, textAlign: 'center', fontWeight: 600 }}>{t.toUpperCase()}</span>
          </div>
          {i < steps.length - 1 && <div style={{ flex: 1, height: 0, borderTop: `2.5px ${s === 'completed' ? 'solid' : 'dashed'} ${s === 'completed' ? d4.ink : d4.ruleSoft}`, marginBottom: 22 }}></div>}
        </React.Fragment>
      ))}
    </div>
  );
}

// ---------------- Course player (work order) ----------------
function D4Player() {
  return (
    <D4Shell active="player" docCode="WO MEC-101">
      {/* Work order header */}
      <div style={{ border: `2.5px solid ${d4.rule}`, background: '#fff', marginBottom: 22 }}>
        <div style={{ display: 'flex' }}>
          <div style={{ flex: 1, padding: '14px 18px', borderRight: `1.5px solid ${d4.rule}` }}>
            <div style={{ fontFamily: d4.mono, fontSize: 9.5, letterSpacing: '0.12em', color: d4.dim }}>WORK ORDER · MODULE</div>
            <div style={{ fontFamily: d4.cond, fontWeight: 700, fontSize: 30, letterSpacing: '0.03em', textTransform: 'uppercase', lineHeight: 1.05, marginTop: 3 }}>Mill Safety & Operation</div>
          </div>
          {[['CODE', 'MEC-101'], ['SUBTEAM', 'MECHANICAL'], ['PREREQ', 'HAND TOOLS ✓'], ['STATUS', 'IN WORK']].map(([l, v], i) => (
            <div key={l} style={{ padding: '14px 16px', borderRight: i < 3 ? `1.5px solid ${d4.rule}` : 'none', minWidth: 110 }}>
              <div style={{ fontFamily: d4.mono, fontSize: 9.5, letterSpacing: '0.12em', color: d4.dim }}>{l}</div>
              <div style={{ fontFamily: d4.mono, fontSize: 13, fontWeight: 700, marginTop: 6, color: v === 'IN WORK' ? d4.orange : d4.ink }}>{v}</div>
            </div>
          ))}
        </div>
        <D4Hazard h={6} color={d4.green} />
        {/* Procedure steps */}
        <div style={{ display: 'flex' }}>
          {PLAYER_BLOCKS.map((b, i) => {
            const cur = b.state === 'current', done = b.state === 'done';
            return (
              <div key={i} style={{ flex: 1, padding: '11px 14px', borderRight: i < 3 ? `1px solid ${d4.ruleSoft}` : 'none', background: cur ? '#F1EFE2' : '#fff' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ width: 15, height: 15, border: `2px solid ${d4.ink}`, background: done ? d4.green : 'transparent', display: 'inline-grid', placeItems: 'center', color: '#fff' }}>{done && Icon.check(9)}</span>
                  <span style={{ fontFamily: d4.mono, fontSize: 10.5, fontWeight: 700 }}>{i + 1}.0 {b.type.toUpperCase()}</span>
                  {cur && <span style={{ fontFamily: d4.mono, fontSize: 9, color: d4.orange, fontWeight: 700 }}>← YOU ARE HERE</span>}
                </div>
                <div style={{ fontSize: 11.5, color: d4.muted, marginTop: 4 }}>{b.title}</div>
              </div>
            );
          })}
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: 26 }}>
        {/* Quiz as form */}
        <div>
          <D4SecHead no="3.0" title="Knowledge check" right={<span style={{ fontFamily: d4.mono, fontSize: 10.5, color: d4.dim }}>Q {QUIZ_QUESTION.n} OF {QUIZ_QUESTION.of} · PASS ≥ 80%</span>} />
          <div style={{ padding: '16px 2px 0' }}>
            <p style={{ margin: '0 0 14px', fontSize: 16.5, fontWeight: 700, lineHeight: 1.45 }}>{QUIZ_QUESTION.n}. {QUIZ_QUESTION.q}</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
              {QUIZ_QUESTION.options.map((o, i) => {
                const picked = i === QUIZ_QUESTION.picked;
                return (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '11px 14px', border: `2px solid ${picked ? d4.ink : d4.ruleSoft}`, background: picked ? '#EAF5EC' : '#fff' }}>
                    <span style={{ width: 17, height: 17, border: `2.5px solid ${d4.ink}`, display: 'grid', placeItems: 'center', flexShrink: 0, background: '#fff' }}>
                      {picked && <span style={{ width: 9, height: 9, background: d4.green }}></span>}
                    </span>
                    <span style={{ fontFamily: d4.mono, fontSize: 11, fontWeight: 700, color: d4.dim }}>{String.fromCharCode(65 + i)}.</span>
                    <span style={{ fontSize: 14 }}>{o}</span>
                  </div>
                );
              })}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 18 }}>
              <span style={{ background: d4.ink, color: '#F4F2E8', fontFamily: d4.cond, fontWeight: 700, fontSize: 16, letterSpacing: '0.12em', textTransform: 'uppercase', padding: '9px 22px' }}>Record answer →</span>
              <span style={{ fontFamily: d4.mono, fontSize: 10.5, color: d4.dim }}>ATTEMPT 1 OF 3</span>
            </div>
          </div>
        </div>

        {/* Mentor sign-off block */}
        <div>
          <D4SecHead no="4.0" title="Mentor sign-off" />
          <div style={{ border: `2px solid ${d4.rule}`, borderTop: 'none', background: '#fff', padding: 14 }}>
            <div style={{ fontFamily: d4.mono, fontSize: 10, letterSpacing: '0.08em', color: d4.muted, marginBottom: 8 }}>CHECKLIST — DEMONSTRATE TO MENTOR</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {CHECKLIST.map((c, i) => (
                <div key={i} style={{ display: 'flex', gap: 9, fontSize: 12, lineHeight: 1.45 }}>
                  <span style={{ width: 13, height: 13, border: `2px solid ${d4.ink}`, flexShrink: 0, marginTop: 2 }}></span>{c}
                </div>
              ))}
            </div>
            <div style={{ marginTop: 16, borderTop: `1.5px dashed ${d4.ruleSoft}`, paddingTop: 12 }}>
              <div style={{ fontFamily: d4.mono, fontSize: 10, color: d4.muted }}>MENTOR SIGNATURE — SCAN STUDENT PASSPORT</div>
              <div style={{ height: 44, borderBottom: `2px solid ${d4.ink}`, display: 'flex', alignItems: 'flex-end', paddingBottom: 4 }}>
                <D4Stamp color={d4.orange} rotate={-3} style={{ fontSize: 12 }}>Awaiting demo</D4Stamp>
              </div>
            </div>
          </div>
        </div>
      </div>
    </D4Shell>
  );
}

// ---------------- Skill tree (route map) ----------------
const d4TeamLine = { Mechanical: d4.green, Electrical: d4.orange, Programming: '#3E7A8C', General: d4.ink };

function D4Tree() {
  const W = 1150, H = 660, mx = 90, my = 50;
  const px = (x) => mx + (x / 100) * (W - mx * 2);
  const py = (y) => my + (y / 100) * (H - my * 2);
  const byId = Object.fromEntries(TREE_NODES.map((n) => [n.id, n]));
  return (
    <D4Shell active="tree" docCode="MAP CR-SM-03">
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 16, marginBottom: 16 }}>
        <div style={{ fontFamily: d4.cond, fontWeight: 700, fontSize: 34, letterSpacing: '0.04em', textTransform: 'uppercase', lineHeight: 1 }}>Certification route map</div>
        <span style={{ flex: 1 }}></span>
        {Object.entries(d4TeamLine).filter(([t]) => t !== 'General').map(([t, c]) => (
          <span key={t} style={{ display: 'inline-flex', alignItems: 'center', gap: 7, fontFamily: d4.mono, fontSize: 10.5, color: d4.muted }}>
            <span style={{ width: 22, height: 5, background: c }}></span>{t.toUpperCase()} LINE
          </span>
        ))}
      </div>
      <div style={{ border: `2.5px solid ${d4.rule}`, background: '#fff', position: 'relative' }}>
        <svg viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', height: 656, display: 'block' }}>
          {/* faint grid */}
          {Array.from({ length: 22 }, (_, i) => <line key={'v' + i} x1={i * 56} y1="0" x2={i * 56} y2={H} stroke="#F0EEE2" strokeWidth="1" />)}
          {Array.from({ length: 13 }, (_, i) => <line key={'h' + i} x1="0" y1={i * 56} x2={W} y2={i * 56} stroke="#F0EEE2" strokeWidth="1" />)}
          {/* transit-style edges, colored by destination team */}
          {TREE_EDGES.map(([a, b], i) => {
            const A = byId[a], B = byId[b];
            const x1 = px(A.x), y1 = py(A.y), x2 = px(B.x), y2 = py(B.y);
            const mid = x1 + (x2 - x1) * 0.55;
            const c = d4TeamLine[B.team];
            const done = A.status === 'completed';
            return <path key={i} d={`M ${x1} ${y1} H ${mid} V ${y2} H ${x2}`} fill="none" stroke={c} strokeWidth={4} strokeDasharray={done ? 'none' : '7 6'} opacity={B.status === 'locked' && !done ? 0.3 : 0.85} strokeLinejoin="round" />;
          })}
          {/* stations */}
          {TREE_NODES.map((n) => {
            const x = px(n.x), y = py(n.y);
            const c = d4TeamLine[n.team];
            const done = n.status === 'completed';
            const cur = n.status === 'in_progress';
            return (
              <g key={n.id}>
                <circle cx={x} cy={y} r={cur ? 13 : 10} fill={done ? c : '#fff'} stroke={n.status === 'locked' ? '#B9BCA9' : d4.ink} strokeWidth={2.5} />
                {done && <path d={`M ${x - 4.5} ${y} l 3 3.5 l 6 -6.5`} stroke="#fff" strokeWidth="2.5" fill="none" strokeLinecap="round" />}
                {cur && <circle cx={x} cy={y} r={5} fill={d4.orange} />}
                <text x={x} y={y - (cur ? 21 : 18)} textAnchor="middle" fontSize="11" fontFamily={d4.mono} fontWeight="700" fill={n.status === 'locked' ? '#9AA08E' : d4.ink}>
                  {n.title.length > 21 ? n.title.slice(0, 20).toUpperCase() + '…' : n.title.toUpperCase()}
                </text>
              </g>
            );
          })}
          {/* terminal marker */}
          <g>
            <rect x={px(92) - 56} y={py(52) + 18} width={112} height={20} fill={d4.ink} />
            <text x={px(92)} y={py(52) + 32} textAnchor="middle" fontSize="10" fontFamily={d4.mono} fontWeight="700" fill="#F4F2E8">TERMINAL · COMP READY</text>
          </g>
        </svg>
        {/* You-are-here */}
        <div style={{ position: 'absolute', left: 22, top: 18, background: '#fff', border: `2px solid ${d4.rule}`, padding: '10px 14px', maxWidth: 250 }}>
          <div style={{ fontFamily: d4.mono, fontSize: 9.5, letterSpacing: '0.1em', color: d4.orange, fontWeight: 700 }}>● YOU ARE HERE</div>
          <div style={{ fontFamily: d4.cond, fontWeight: 700, fontSize: 18, textTransform: 'uppercase', letterSpacing: '0.04em', margin: '3px 0 2px' }}>Mill Safety & Operation</div>
          <div style={{ fontSize: 11.5, color: d4.muted }}>Quiz in progress · then mentor demo. Next stop: Lathe Certification.</div>
        </div>
      </div>
    </D4Shell>
  );
}

Object.assign(window, { D4Dashboard, D4Player, D4Tree });
